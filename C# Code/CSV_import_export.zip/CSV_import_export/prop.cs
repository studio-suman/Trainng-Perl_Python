using System;
using System.Collections.Generic;
using System.Text;

namespace CSV_import_export
{

	// properties
	class prop
	{
		//******************************************************
		// conection string - REPLACE it, if you need.
		public static string sqlConnString = "server=(local);database=Test_CSV_impex;Trusted_Connection=True";
		//******************************************************


	}
}
