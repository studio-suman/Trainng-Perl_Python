var sStr = require('./Literals.js');

console.log(sStr.iDuration);
console.log(sStr);
