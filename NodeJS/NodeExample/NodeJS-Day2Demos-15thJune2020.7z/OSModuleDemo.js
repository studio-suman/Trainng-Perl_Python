var refOs = require('os');

console.log(refOs.platform());
console.log(refOs.homedir());
console.log(' HostName = ' + refOs.hostname);
console.log(refOs.endianness());