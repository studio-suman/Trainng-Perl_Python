module.exports ={
	sTraining :' Node JS', 
	sMode: 'Web-Ex',
	sFeedBack :' Feeling Sleepy , Boring Training '
};
module.exports.iDuration = 4;

module.exports.myDateTime = function(){
	return Date();
}

module.exports.addNumbers = function(iFirst,iSecond){
	 return iFirst + iSecond;
}

module.exports.objEmployee = {
	iEno:21,empName:"Nirekha",empLocation:"Chennai"
}

