module.exports = function(){
	console.log(' Demo for functions ');
}