
var objCustomModule = require('./Literals.js');
var objAnonyFun = require('./Functions');
console.log(objCustomModule);

console.log(" Name of the Employee  = " + objCustomModule.objEmployee.empName);

objAnonyFun();