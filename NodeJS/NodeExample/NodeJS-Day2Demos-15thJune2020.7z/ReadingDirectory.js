var refFile = require('fs');

refFile.readdir('C:\\Users\\mbabu86\\Desktop\\NodeJS',function(refError,objFiles){
   if (refError)
      console.log(' Error in Accessing the directory ' );
   objFiles.forEach(function(refFile){
       console.log(refFile);
   });
});