module.exports ={
	sTraining :' Node JS', 
	sMode: 'Web-Ex',
	sFeedBack :' Feeling Sleepy , Boring Training '
};
module.exports.objEmployee = {iEno:12,sName:'Magesh'};
module.exports.iDuration = 4;

module.exports.addNumbers = function(iFirst,iSecond){
	 var iResult = iFirst + iSecond;
	 console.log(' iResult = ' + iResult);
}


