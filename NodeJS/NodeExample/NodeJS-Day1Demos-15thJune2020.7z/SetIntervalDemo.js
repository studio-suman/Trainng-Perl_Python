setInterval(trngConclude,1000);

function trngConclude(){
   console.log('We will conclude the training at 5:30 PM ');
}

setInterval(function(){
console.log('Learning Node JS from TT');
},1000);
console.log(' After setTimeout() ');


