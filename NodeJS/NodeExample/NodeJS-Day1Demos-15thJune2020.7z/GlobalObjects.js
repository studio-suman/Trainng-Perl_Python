/* Global Object Demonstration */
console.log(" Current Working Directory = " + __dirname);
console.log(" Name of the Script = " + __filename);

//console.log(console);

//console.error(new Error("Boring Training"));

console.warn("At what time we will conclude for the day");

console.log(process);