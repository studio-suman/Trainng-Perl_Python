import json
from lab45_autogen_extension.utils import Lab45AIPlatformRequestUtils
import requests

PLATFORM_FETCH_FILE_ENDPOINT = "agent_chat_session/script_agent/fetch"

class FileManager:
    def __init__(self, base_url, api_key):
        self.fetch_endpoint = base_url + PLATFORM_FETCH_FILE_ENDPOINT
        self.api_key = api_key

    def read_file(self, party_id, file_name):
        payload = json.dumps({"party_id":party_id, "file_name":file_name})
        headers = Lab45AIPlatformRequestUtils.get_headers(api_key=self.api_key)
        response = requests.request("POST", self.fetch_endpoint, headers=headers, data=payload)
        response.raise_for_status()
        return response.content