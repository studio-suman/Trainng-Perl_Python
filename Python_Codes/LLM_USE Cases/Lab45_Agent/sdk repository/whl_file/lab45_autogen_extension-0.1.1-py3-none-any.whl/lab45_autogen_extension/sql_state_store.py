import sqlite3
import json
import os
import logging
import threading
from datetime import datetime
from typing import Optional, Dict, Any, Union

# --- Configuration ---
# Basic logging setup
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Use a thread-local storage for database connections to avoid sharing
# connections across threads if the application uses threading.
# For multi-processing (like Gunicorn workers), each process will
# get its own instance of this class and manage its own connections.
local_storage = threading.local()

class SQLiteStateStore:
    """
    Manages storing and retrieving arbitrary JSON payloads in an SQLite database
    associated with graph, user, and session IDs.

    Handles database initialization and provides cleanup functionality.
    Designed to work with a database file on a persistent volume.
    Uses WAL mode and a busy timeout for better concurrency handling
    with multiple Gunicorn workers (processes).
    """

    def __init__(self, db_path: str, busy_timeout_ms: int = 5000):
        """
        Initializes the state store.

        Args:
            db_path: The full path to the SQLite database file.
            busy_timeout_ms: Timeout in milliseconds to wait if the database
                             is locked before raising an error.
        """
        if not db_path:
            raise ValueError("Database path cannot be empty.")

        self.db_path = db_path
        self.busy_timeout_ms = busy_timeout_ms
        self._db_initialized = False
        self._lock = threading.Lock() # Lock for thread-safe initialization check

        # Ensure the directory exists and initialize the database/schema
        try:
            self._ensure_db_initialized()
        except Exception as e:
            logger.exception(f"CRITICAL: Failed to initialize database at {self.db_path}")
            # Depending on requirements, you might want to re-raise
            # or exit if the DB can't be initialized.
            # raise

    def _get_connection(self) -> sqlite3.Connection:
        """
        Gets a connection to the SQLite database for the current thread/process.
        Enables WAL mode and sets busy timeout.
        """
        # Check if connection already exists for this thread/process context
        # Note: In a multi-process Gunicorn setup, each worker process
        # will typically call this independently.
        if hasattr(local_storage, 'connection') and local_storage.connection:
             # Basic check: See if connection is still alive
             try:
                 # Simple operation to test connection
                 local_storage.connection.execute("SELECT 1;")
                 return local_storage.connection
             except (sqlite3.ProgrammingError, sqlite3.OperationalError):
                 logger.warning("Existing connection seems closed. Reconnecting.")
                 try:
                     local_storage.connection.close()
                 except Exception:
                     pass # Ignore errors during close of potentially bad connection

        try:
            logger.debug(f"Attempting to connect to database: {self.db_path}")
            # isolation_level=None enables autocommit mode.
            # We will manage transactions manually with begin/commit/rollback.
            # Or set it to DEFERRED (default), EXCLUSIVE, or IMMEDIATE
            # Use detect_types for timestamp handling
            connection = sqlite3.connect(
                self.db_path,
                timeout=self.busy_timeout_ms / 1000.0, # timeout expects seconds
                detect_types=sqlite3.PARSE_DECLTYPES | sqlite3.PARSE_COLNAMES,
                check_same_thread=False # Required for thread local, but be careful
                                        # We ensure safety by not sharing connection objects
                                        # between threads explicitly
            )
            # Enable Write-Ahead Logging for better concurrency
            connection.execute("PRAGMA journal_mode=WAL;")
            # Set busy timeout directly via PRAGMA as well (belt and suspenders)
            connection.execute(f"PRAGMA busy_timeout = {self.busy_timeout_ms};")
            logger.debug(f"Database connection successful to {self.db_path}, WAL enabled.")
            # Store the connection in thread-local storage
            local_storage.connection = connection
            return connection
        except sqlite3.OperationalError as e:
            logger.error(f"Could not connect to or configure database at {self.db_path}: {e}")
            raise
        except Exception as e:
            logger.exception(f"An unexpected error occurred during DB connection to {self.db_path}")
            raise

    def _close_connection(self):
        """Closes the connection stored in thread-local storage if it exists."""
        if hasattr(local_storage, 'connection') and local_storage.connection:
            try:
                local_storage.connection.close()
                logger.debug("Database connection closed.")
            except Exception as e:
                logger.exception(f"Error closing database connection: {e}")
            finally:
                 # Remove from local storage
                delattr(local_storage, 'connection')


    def _ensure_db_initialized(self):
        """Checks if DB is initialized and initializes if not. Thread-safe."""
        # Quick check without lock first
        if self._db_initialized:
            return

        with self._lock:
            # Double check after acquiring lock
            if self._db_initialized:
                return

            logger.info(f"Initializing database schema for {self.db_path}...")
            db_dir = os.path.dirname(self.db_path)
            if db_dir and not os.path.exists(db_dir):
                try:
                    os.makedirs(db_dir, exist_ok=True)
                    logger.info(f"Created directory for database: {db_dir}")
                except OSError as e:
                    logger.error(f"Failed to create directory {db_dir}: {e}")
                    raise # Cannot proceed without directory

            conn = None
            try:
                conn = self._get_connection()
                cursor = conn.cursor()

                # Create table schema
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS state_store (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                        graph_id TEXT NULL,
                        user_id TEXT NOT NULL,
                        session_id TEXT NOT NULL,
                        tenant_id TEXT NOT NULL,
                        payload TEXT NOT NULL
                    )
                """)
                logger.info("Table 'state_store' ensured to exist.")

                # Create index for efficient retrieval of the latest state
                cursor.execute("""
                    CREATE INDEX IF NOT EXISTS idx_state_lookup
                    ON state_store (graph_id, user_id, session_id, timestamp DESC)
                """)
                logger.info("Index 'idx_state_lookup' ensured to exist.")

                conn.commit()
                self._db_initialized = True
                logger.info(f"Database initialization complete for {self.db_path}")

            except sqlite3.Error as e:
                logger.error(f"SQLite error during initialization: {e}")
                if conn:
                    conn.rollback() # Rollback any partial changes
                raise # Re-raise after logging
            except Exception as e:
                 logger.exception("Unexpected error during database initialization.")
                 if conn:
                     conn.rollback()
                 raise
            finally:
                 # Close the connection used for initialization if it was opened
                 # Don't use self._close_connection() here as it might interfere
                 # with a connection potentially needed by the caller thread right after.
                 if conn and conn != getattr(local_storage, 'connection', None):
                     conn.close()


    def store_state(self,tenant_id: str, user_id: str, session_id: str, payload: Union[Dict, Any],graph_id= "") -> bool:
        """
        Stores a JSON payload associated with the given IDs.

        Args:
            graph_id: The graph identifier. Can be null.
            tenant_id: The tenant identifier,
            user_id: The user identifier.
            session_id: The session identifier.
            payload: The Python dictionary or object to store (must be JSON serializable).

        Returns:
            True if successful, False otherwise.
        """
        if not all([tenant_id, user_id, session_id]):
             logger.warning("Attempted to store state with missing IDs.")
             return False

        conn = None
        try:
            payload_str = json.dumps(payload) # Check serialization early
            conn = self._get_connection()
            cursor = conn.cursor()
            logger.debug(f"Storing state for {tenant_id}/{user_id}/{session_id}/{graph_id}")
            existing_state = self.retrieve_latest_state(tenant_id,user_id,session_id,graph_id)
            operation_mode= " saved "
            if existing_state is not None:
                operation_mode=" updated "
                cursor.execute("""
                    UPDATE state_store SET payload = ?
                    WHERE graph_id = ? AND tenant_id = ? AND user_id = ? AND session_id = ?
                """, (payload_str,graph_id,tenant_id, user_id, session_id))              
            else:   
                cursor.execute("""
                    INSERT INTO state_store (graph_id,tenant_id, user_id, session_id, payload)
                    VALUES (?, ?, ?, ?, ?)
                """, (graph_id,tenant_id, user_id, session_id, payload_str))

            conn.commit()
            logger.info(f"Successfully "+operation_mode+f" state for {tenant_id}/{user_id}/{session_id}/{graph_id}")
            return True

        except json.JSONDecodeError as e:
            logger.error(f"Failed to serialize payload to JSON: {e}", exc_info=True)
            return False
        except sqlite3.OperationalError as e:
             # Specific handling for busy/locked database
            if "database is locked" in str(e).lower():
                logger.warning(f"Database was locked trying to store state for {tenant_id}/{user_id}/{session_id}/{graph_id}. Timeout: {self.busy_timeout_ms}ms. Operation failed.")
            else:
                logger.error(f"SQLite operational error storing state: {e}", exc_info=True)
            if conn:
                conn.rollback()
            return False
        except sqlite3.Error as e:
            logger.error(f"SQLite error storing state: {e}", exc_info=True)
            if conn:
                conn.rollback()
            return False
        except Exception as e:
            logger.exception("Unexpected error storing state.")
            if conn:
                conn.rollback()
            return False
        # No finally block to close connection here - let _get_connection manage lifecycle

    def retrieve_latest_state(self,tenant_id: str, user_id: str, session_id: str,graph_id= "") -> Optional[Dict[str, Any]]:
        """
        Retrieves the most recently stored JSON payload for the given IDs.

        Args:
            tenant_id: The tenant identifier,
            user_id: The user identifier.
            session_id: The session identifier.
            graph_id: The graph identifier. Can be empty.

        Returns:
            The deserialized JSON payload as a dictionary, or None if not found or on error.
        """
        if not all([tenant_id, user_id, session_id]):
             logger.warning("Attempted to retrieve state with missing IDs.")
             return None

        conn = None
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            logger.debug(f"Retrieving latest state for {tenant_id}/{user_id}/{session_id}/{graph_id}")

            cursor.execute("""
                SELECT payload
                FROM state_store
                WHERE graph_id = ? AND tenant_id= ? AND user_id = ? AND session_id = ?
                ORDER BY timestamp DESC
                LIMIT 1
            """, (graph_id,tenant_id, user_id, session_id))

            row = cursor.fetchone()

            if row:
                payload_str = row[0]
                try:
                    payload = json.loads(payload_str)
                    logger.info(f"Successfully retrieved state for {tenant_id}/{user_id}/{session_id}/{graph_id}")
                    return payload
                except json.JSONDecodeError as e:
                    logger.error(f"Failed to decode JSON payload from DB for {tenant_id}/{user_id}/{session_id}/{graph_id}: {e}", exc_info=True)
                    return None
            else:
                logger.info(f"No state found for {tenant_id}/{user_id}/{session_id}/{graph_id}")
                return None

        except sqlite3.OperationalError as e:
             if "database is locked" in str(e).lower():
                 logger.warning(f"Database was locked trying to retrieve state for {tenant_id}/{user_id}/{session_id}/{graph_id}. Timeout: {self.busy_timeout_ms}ms. Operation failed.")
             else:
                 logger.error(f"SQLite operational error retrieving state: {e}", exc_info=True)
             return None
        except sqlite3.Error as e:
            logger.error(f"SQLite error retrieving state: {e}", exc_info=True)
            return None
        except Exception as e:
            logger.exception("Unexpected error retrieving state.")
            return None
        # No finally block to close connection

    def cleanup_state(self,tenant_id: str, user_id: str, session_id: str,graph_id= "") -> int:
        """
        Deletes all state records matching the given IDs.

        Args:
            tenant_id: The tenant identifier,
            user_id: The user identifier.
            session_id: The session identifier.
            graph_id: The graph identifier. Can be empty.

        Returns:
            The number of records deleted. Returns -1 on error.
        """
        if not all([tenant_id, user_id, session_id]):
             logger.warning("Attempted to cleanup state with missing IDs.")
             return -1

        conn = None
        deleted_count = -1
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            logger.debug(f"Cleaning up state for {tenant_id}/{user_id}/{session_id}/{graph_id}")

            cursor.execute("""
                DELETE FROM state_store
                WHERE graph_id = ? AND tenant_id= ? AND user_id = ? AND session_id = ?
            """, (graph_id,tenant_id, user_id, session_id))

            deleted_count = cursor.rowcount
            conn.commit()
            logger.info(f"Cleaned up {deleted_count} state records for {tenant_id}/{user_id}/{session_id}/{graph_id}.")
            return deleted_count

        except sqlite3.OperationalError as e:
            if "database is locked" in str(e).lower():
                 logger.warning(f"Database was locked trying to clean up state for {tenant_id}/{user_id}/{session_id}/{graph_id}. Timeout: {self.busy_timeout_ms}ms. Operation failed.")
            else:
                 logger.error(f"SQLite operational error cleaning up state: {e}", exc_info=True)
            if conn:
                conn.rollback()
            return -1 # Indicate error
        except sqlite3.Error as e:
            logger.error(f"SQLite error cleaning up state: {e}", exc_info=True)
            if conn:
                conn.rollback()
            return -1 # Indicate error
        except Exception as e:
            logger.exception("Unexpected error cleaning up state.")
            if conn:
                conn.rollback()
            return -1 # Indicate error
        # No finally block to close connection

    def close(self):
        """Manually closes the connection for the current context if needed."""
        logger.info("Explicitly closing state store connection for this context.")
        self._close_connection()
