from strenum import StrEnum
from enum import auto

class ImageModelsList(StrEnum):
    """
    Text to image generation models
    """
    dalle = auto()
    stablediffusion = auto()

class TextToImageTools(StrEnum):
    """
    Pre-built Text to Image tools available in the platform
    """
    DalleText2ImageTool = auto()
    StableDiffusionText2ImageTool = auto()

class TextToSlideTools(StrEnum):
    """
    Pre-built Text to Slide tools available in the platform
    """
    SlideToolWithDallE = auto()
    SlideToolWithStableDiffusion = auto()

class SearchTools(StrEnum):
    """
    Pre-built Search tools available in the platform
    """
    BingSearchTool = auto()

class TextToFlowchartTools(StrEnum):
    """
    Pre-built Text to Flowchart tools available in the platform
    """
    UMLText2FlowchartTool = auto()