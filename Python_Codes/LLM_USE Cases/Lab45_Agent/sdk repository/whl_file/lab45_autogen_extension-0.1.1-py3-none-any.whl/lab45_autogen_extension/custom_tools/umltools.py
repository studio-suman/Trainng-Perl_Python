from typing import Optional, Type
from pydantic import BaseModel, Field
from langchain.callbacks.manager import AsyncCallbackManagerForToolRun
from lab45_autogen_extension.custom_tools.basetool import Lab45AIPlatformBaseTool
from lab45_autogen_extension.custom_tools.tool_enums import TextToFlowchartTools


class PythonInputs(BaseModel):
    """Python inputs."""
    query: str = Field(description="The text derived from user query which is the input to the image generation model.")

class Lab45AIPlatformText2FlowchartTool(Lab45AIPlatformBaseTool):
    name: str = "Lab45AIPlatformText2FlowchartTool"
    description: str = "Useful when you need to generate or create an flowchart from text description."
    conversation_id: str = None
    args_schema: Type[BaseModel] = PythonInputs

    def __init__(self, conversation_id=None, **kwargs) -> None:
        super().__init__(**kwargs)
        self.conversation_id = conversation_id

    async def _run(self, query: str, run_manager: Optional[AsyncCallbackManagerForToolRun] = None) -> str:
        """Use the tool asynchronously."""
        text2flowchart_tool = TextToFlowchartTools.UMLText2FlowchartTool
        response = await self.generate_tool_response(tool_name=text2flowchart_tool, query=query)
        return response