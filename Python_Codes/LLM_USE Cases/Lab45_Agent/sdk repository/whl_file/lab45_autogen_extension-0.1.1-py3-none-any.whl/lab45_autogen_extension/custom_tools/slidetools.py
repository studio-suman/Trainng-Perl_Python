from typing import Optional, Type
from pydantic import BaseModel, Field
from langchain.callbacks.manager import AsyncCallbackManagerForToolRun
from tool_enums import TextToSlideTools, ImageModelsList
from basetool import Lab45AIPlatformBaseTool

SLIDE_TOOL_MAP = {
    ImageModelsList.dalle: TextToSlideTools.SlideToolWithDallE,
    ImageModelsList.stablediffusion: TextToSlideTools.SlideToolWithStableDiffusion
}

class PythonInputs(BaseModel):
    """Python inputs."""
    query: str = Field(description="The text derived from user query which is the input to the slide generation tool. \
                       This will be in the same json format as mentioned in the tool description.")

class Lab45AIPlatformSlideGenerationTool(Lab45AIPlatformBaseTool):
    name: str = "Lab45AIPlatformSlideGenerationTool"
    description: str = ("Useful when you need to generate or create slides, presentation, \
        slide deck or pitch deck from text description. The query parameter takes in a json structure")
    image_model: ImageModelsList
    conversation_id: str
    args_schema: Type[BaseModel] = PythonInputs

    def __init__(self, image_model=ImageModelsList.dalle, conversation_id=None) -> None:
        super().__init__()
        self.image_model = image_model
        self.conversation_id = conversation_id

    async def _run(self, query: str, run_manager: Optional[AsyncCallbackManagerForToolRun] = None) -> str:
        """Use the tool asynchronously."""
        slide_tool = SLIDE_TOOL_MAP.get(self.image_model)
        response = await self.generate_tool_response(tool_name=slide_tool, query=query)
        return response
