from typing import Optional, Type
from pydantic import BaseModel, Field
from langchain.callbacks.manager import AsyncCallbackManagerForToolRun
from lab45_autogen_extension.custom_tools.basetool import Lab45AIPlatformBaseTool
from lab45_autogen_extension.custom_tools.tool_enums import ImageModelsList, TextToImageTools

IMAGE_TOOL_MAP = {
    ImageModelsList.dalle: TextToImageTools.DalleText2ImageTool,
    ImageModelsList.stablediffusion: TextToImageTools.StableDiffusionText2ImageTool
}

class PythonInputs(BaseModel):
    """Python inputs."""
    query: str = Field(description="The text derived from user query which is the input to the image generation model.")

class Lab45AIPlatformText2ImageTool(Lab45AIPlatformBaseTool):
    name: str = "Lab45AIPlatformText2ImageTool"
    description: str = "Useful when you need to generate or create an image from text description."
    image_model: ImageModelsList=ImageModelsList.dalle
    conversation_id: str=None
    args_schema: Type[BaseModel] = PythonInputs

    def __init__(self, image_model: str=ImageModelsList.dalle, conversation_id=None, **kwargs) -> None:
        super().__init__(**kwargs)
        self.image_model = image_model
        self.conversation_id = conversation_id

    async def _run(self, query: str, run_manager: Optional[AsyncCallbackManagerForToolRun] = None) -> str:
        """Use the tool asynchronously."""
        text2image_tool = IMAGE_TOOL_MAP.get(self.image_model)
        response = await self.generate_tool_response(tool_name=text2image_tool, query=query)
        return response