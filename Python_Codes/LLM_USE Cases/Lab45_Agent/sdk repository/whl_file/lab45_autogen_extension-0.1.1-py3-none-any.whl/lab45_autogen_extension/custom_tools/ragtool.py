from typing import Any, Dict, List, Optional, Type
import asyncio
import json

from pydantic import BaseModel, Field
from langchain.callbacks.manager import AsyncCallbackManagerForToolRun

from lab45_autogen_extension.errors import Lab45AIPlatformToolRequestError
from lab45_autogen_extension.utils import Lab45AIPlatformRequestUtils, ModelNames
from lab45_autogen_extension.custom_tools.basetool import Lab45AIPlatformBaseTool
import re


UUID_REGEXR = r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$'
DEFAULT_SKILL_PARAMS = {
    "model_name": "gpt-4o",
    "return_usage_stats": True,
    "return_sources": False,
    "top_k": 15
  }

class PythonInputs(BaseModel):
    """Python inputs."""
    query: str = Field(description="This parameter exactly matches the user's input without any alterations. \
                       Do not re-write the query prompt, copy the original as is. \
                       This is the query that the user wants answers to from the indexed RAG dataset.")

class Lab45AIPlatformRAGTool(Lab45AIPlatformBaseTool):
    name: str = "Lab45AIPlatformRAGTool"
    description: str = (
        "This tool interfaces with a pre-indexed document set using a Retrieval-Augmented Generation (RAG) pipeline. "
        "For any queries beyond basic greetings, the LLM should prioritize selecting the 'Lab45AIPlatformRAGTool' function/tool. "
        "If multiple tools are available, this tool should be the default choice when no other tool matches the query. "
        "Ensure that the 'query' parameter exactly matches the user's input without any alterations."
        "Do not re-write the query prompt, copy the original as is."
    )
    dataset_id: str = None
    message_history: Optional[List[Dict[str, str]]] = Field(
        default=None,
        description=(
            "List of messages in the format: [{'content': 'Hi, generate an image of a flower', 'name': 'user', 'role': 'user'}], "
            "where 'name' is variable and 'role' can take one of 'user', 'system', 'assistant' or 'function'"
        ),
        example=[
            {
                "content": "Hi, generate an image of a flower",
                "name": "user",
                "role": "user"
            }
        ]
    )
    username: str = Field(default="user", description="The username of the person using the tool.")
    conversation_id: Optional[str] = Field(default=None, description="The conversation ID, if any.")
    args_schema: Type[BaseModel] = PythonInputs
    model_name: ModelNames = Field(default=ModelNames.gpt_4o, description="The model name to use. Must be one of the values in the ModelNames enum.")
    top_k: int = Field(default=10, ge=1, le=100, description="The number of top documents to retrieve. Must be between 1 and 100.")

    def __init__(
        self,
        dataset_id: str = None,
        message_history: Optional[List[Dict[str, str]]] = None,
        username: str = 'user',
        model_name: str = "gpt-4",
        top_k: int = 10,
        conversation_id: Optional[str] = None,
        **kwargs
    ) -> None:
        super().__init__(**kwargs)
        if not dataset_id or not re.match(UUID_REGEXR, dataset_id):
            raise ValueError(f"Invalid UUID format or missing required dataset_id field: {dataset_id}")
        self.dataset_id = dataset_id
        self.message_history = message_history
        self.username = username
        self.conversation_id = conversation_id
        self.top_k = top_k
        self.model_name = ModelNames(model_name)

    def generate_payload(self, query: str) -> Dict[str, Any]:
        """
        Generate the payload for the document completion request.

        Args:
            query (str): The user query.

        Returns:
            Dict[str, Any]: The payload for the request.
        """
        message = {
            "content": query,
            "name": self.username,
            "role": "user"
        }
        skill_params = {**DEFAULT_SKILL_PARAMS, "model_name": self.model_name.value, "top_k": self.top_k}

        if self.message_history is None:
            self.message_history = [message]
        else:
            self.message_history.append(message)

        #TODO: Streaming responses for document completion tool
        #TODO: Handle return_sources support?
        return json.dumps({
            "dataset_id": self.dataset_id,
            "messages": self.message_history,
            "skill_parameters": skill_params,
            "stream_response": False
        })

    async def execute_platform_document_completion(self, payload) -> Any:
        """
        Execute the platform document completion asynchronously.

        Returns:
            Any: The response from the document completion endpoint.
        """
        # Implementation for executing the document completion
        laip_request_utils = Lab45AIPlatformRequestUtils(request_url=self.doc_completion_url, model_name=self.model_name)

        future = asyncio.ensure_future(
            laip_request_utils.completion_call(payload, self.get_headers(self.api_key)))
        response = await future

        try:
            if response["data"].get("content"):
                response = response["data"].get("content")
        except Exception as err:
            raise Lab45AIPlatformToolRequestError(message=f"No relevant response from tool \
                    execution API, with error msg: {str(err)}")

        return response

    async def _run(self, query: str, run_manager: Optional[AsyncCallbackManagerForToolRun] = None) -> str:
        """
        Asynchronous run method.

        Args:
            query (str): The user query against already indexed dataset.

        Returns:
            str: The response from the document completion.
        """
        payload = self.generate_payload(query)
        response = await self.execute_platform_document_completion(payload)
        return response
