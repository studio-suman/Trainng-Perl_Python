from typing import Optional, Type
from pydantic import BaseModel, Field
from langchain.callbacks.manager import AsyncCallbackManagerForToolRun
from lab45_autogen_extension.custom_tools.basetool import Lab45AIPlatformBaseTool
from lab45_autogen_extension.custom_tools.tool_enums import SearchTools

class PythonInputs(BaseModel):
    """Python inputs."""
    query: str = Field(description="The text derived from user query which is the input to the Bing search API for performing the live search. \
                       Will be same as user query")

class Lab45AIPlatformBingSearchTool(Lab45AIPlatformBaseTool):
    name: str = "Lab45AIPlatformBingSearchTool"
    description: str = "Useful when you need to search the web using Bing Search API. \
        Any query requesting latest or current information can make use of this tool."
    conversation_id: str = None
    args_schema: Type[BaseModel] = PythonInputs

    def __init__(self, conversation_id=None) -> None:
        super().__init__()
        self.conversation_id = conversation_id

    async def _run(self, query: str, run_manager: Optional[AsyncCallbackManagerForToolRun] = None) -> str:
        """Use the tool asynchronously."""
        text2image_tool = SearchTools.BingSearchTool
        response = await self.generate_tool_response(tool_name=text2image_tool, query=query)
        return response