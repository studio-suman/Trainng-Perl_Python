import os
import json
import asyncio
from abc import ABC
from urllib.parse import urljoin
from langchain.tools import BaseTool
from lab45_autogen_extension.utils import Lab45AIPlatformRequestUtils, ModelNames
from lab45_autogen_extension.errors import Lab45AIPlatformToolRequestError


class Lab45AIPlatformBaseTool(BaseTool, ABC):
    base_url: str = None
    api_key: str = None
    doc_completion_url: str = None
    laip_request_utils: Lab45AIPlatformRequestUtils = None
    PLATFORM_TOOL_EXECUTION_ENDPOINT: str = "agent_chat_session/execute_tools"
    PLATFORM_DOCUMENT_COMPLETION_ENDPOINT: str = "skills/doc_completion/query"

    def __init__(self, **kwargs) -> None:
        super().__init__()
        self.base_url = kwargs.get('base_url', os.getenv("LAB45AIPLATFORM_URL"))
        self.api_key = kwargs.get('api_key', os.getenv("LAB45AIPLATFORM_API_KEY"))
        self.laip_request_utils = Lab45AIPlatformRequestUtils(
            request_url=urljoin(self.base_url, self.PLATFORM_TOOL_EXECUTION_ENDPOINT),
            model_name=kwargs.get('model_name', ModelNames.gpt_4o)
        )
        self.doc_completion_url = urljoin(self.base_url, self.PLATFORM_DOCUMENT_COMPLETION_ENDPOINT)

    @staticmethod
    def _generate_tool_execution_payload(tool_name, **kwargs):
        return {"name": tool_name, "arguments": kwargs}

    @staticmethod
    def _generate_request_payload(tool_info, conversation_id=None) -> str:
        return json.dumps({
            "conversation_id": conversation_id,
            "tool_info": tool_info
        })

    @staticmethod
    def get_headers(api_key: str):
        return {
            'Content-Type': 'application/json',
            'Authorization': f"Bearer {api_key}"
        }

    async def generate_tool_response(self, tool_name, **tool_options):
        """
        Asynchronously generates a response from a specified tool.

        Args:
            tool_name (str): The name of the tool to execute.
            **tool_options: Other required tool specific parameters.

        Returns:
            str: The result content from the tool execution if available.

        Raises:
            Lab45AIPlatformToolRequestError: If there is no relevant response from the tool execution API.
        """
        payload = self._generate_request_payload(
            self._generate_tool_execution_payload(tool_name, **tool_options),
            self.conversation_id
        )

        response = await asyncio.ensure_future(
            self.laip_request_utils.completion_call(payload, self.get_headers(self.api_key))
        )

        try:
            content = response["data"].get("content")
            if content[0].get("name") != tool_name:
                raise Lab45AIPlatformToolRequestError(
                    message=f"Tool name mismatch in response, expected: {tool_name}, got: {content[0].get('name')}"
            )
            if content:
                return content[0].get("result")
        except Exception as err:
            raise Lab45AIPlatformToolRequestError(
                message=f"No relevant response from tool execution API, with error msg: {str(err)}"
            )
