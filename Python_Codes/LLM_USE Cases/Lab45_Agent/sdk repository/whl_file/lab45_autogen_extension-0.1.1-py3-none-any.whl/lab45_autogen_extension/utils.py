import json
import re
from typing import Optional, Sequence, List, cast
from dataclasses import asdict
from typing_extensions import TypedDict
from strenum import StrEnum
import aiohttp

from autogen_core.models import (
    LLMMessage, SystemMessage, AssistantMessage, UserMessage,
    FunctionExecutionResultMessage
)
from autogen_agentchat.messages import TextMessage
from autogen_core import FunctionCall, Image
from autogen_core.tools import Tool, ToolSchema
from openai.types.shared_params import FunctionDefinition, FunctionParameters
from openai.types.chat import ChatCompletionToolParam
from lab45_autogen_extension.errors import Lab45AIPlatformRequestError

FINISH_REASONS = {
        "tool_calls": "function_calls",
        "stop": "stop",
    }

class ModelNames(StrEnum):
    """
    Generation models available with the platform
    """
    gpt_4 = "gpt-4"
    gpt_4o = "gpt-4o"
    gemini_pro = "gemini-pro"
    gemini_15_pro = "gemini-1.5-pro"
    gemini_15_flash = "gemini-1.5-flash"

ModelsSupportingMultimodal = set([
    ModelNames.gpt_4o,
    ModelNames.gemini_15_pro, 
    ModelNames.gemini_15_flash
])

class Lab45AIPlatformArguments(TypedDict, total=False):
    model_name: Optional[str]
    max_output_tokens: Optional[int]
    return_sources: Optional[bool]
    temperature: Optional[float]
    top_k: Optional[int]

class Lab45AIPlatformClientConfiguration(Lab45AIPlatformArguments, total=False):
    dataset_id: str
    api_key: str
    base_url: Optional[str]
    messages: List[str]
    stream_response: Optional[str]
    enable_state_storage: Optional[bool]

class Lab45AIPlatformStateStoreConfiguration(Lab45AIPlatformArguments, total=False):
    tenant_id: str
    session_id: str
    user_id: str
    query: TextMessage
    api_key: str
    dataset_id:  Optional[str]

class Lab45AIPlatformRequestUtils:
    """
    Class handling all API request and response related functions and utils
    """
    def __init__(self, request_url, model_name=ModelNames.gpt_4o):
        self.request_url = request_url
        self.model_name = model_name

    def create_payload(self, messages: List[str], model_name: str, 
                       stream_response: bool=False, tool_schemas: List[ChatCompletionToolParam]=None,
                       return_usage_stats: bool=False):
        payload = json.dumps({
            "messages": messages,
            "skill_parameters": {
                "model_name": model_name,
                "return_usage_stats": return_usage_stats
            },
            "stream_response": stream_response,
            "tool_schemas": tool_schemas
        })
        return payload

    @staticmethod
    def get_headers(api_key: str):
        headers = {
            'Content-Type': 'application/json',
            'Authorization': "Bearer " + api_key
        }
        return headers

    async def completion_call(self, payload: str, headers: dict, stream_response: bool=False):
        """
        Async completion request to the platform's completion endpoint
        """
        async with aiohttp.ClientSession() as session:
            try:
                async with session.post(self.request_url, data=payload, headers=headers) as response:
                    if response.status == 200:
                        return await response.json()
                    raise Lab45AIPlatformRequestError(
                        message=f"Platform completion request for url: {self.request_url} failed with status: {response.status}")
            except Exception as e:
                raise Lab45AIPlatformRequestError(message=f"Platform completion request for url: {self.request_url} failed with exception: {str(e)}")
            
    def check_multimodal_support(self) -> bool:
        """
        Multi-modal inputs are supported by selected models in the platform, this function validates the same
        """
        if self.model_name not in ModelsSupportingMultimodal:
            raise Lab45AIPlatformRequestError(message=f"Model {self.model_name} does not support multimodal inputs in Lab45 AI Platform")
        return True

    def convert_autogen_message_to_laip_message(self, message: LLMMessage):
        """
        Convert messages in Autogen format to ones compatible with the platform
        """
        role = message.__class__.__name__.replace("Message", "").lower()
        converted_msg = {"role": role}

        if isinstance(message, SystemMessage):
            if not isinstance(message.content, str):
                raise ValueError(f"Invalid content type for {role} message")
            converted_msg["content"] = message.content

        elif isinstance(message, AssistantMessage):
            if isinstance(message.content, str):
                converted_msg["content"] = message.content
            elif isinstance(message.content, list) and message.content and isinstance(message.content[0], FunctionCall):
                # adding messages with FunctionCall content is not compatible with platform schema
                return None
            else:
                raise ValueError(f"Invalid content type for assistant message")

        elif isinstance(message, UserMessage):
            if isinstance(message.content, str):
                converted_msg["content"] = message.content
            elif isinstance(message.content, list) and message.content:
                content = []
                for msg_content in message.content:
                    if isinstance(msg_content, str):
                        content.append({"type": "text", "text": msg_content})
                    elif isinstance(msg_content, Image):
                        self.check_multimodal_support()
                        content.append({"type": "image_url", "image_url": {"url": msg_content.data_uri}})
                    else:
                        raise ValueError(f"Invalid message.content type for user message")
                converted_msg["content"] = content
            else:
                raise ValueError(f"Invalid content type for user message")

        elif isinstance(message, FunctionExecutionResultMessage):
            # TODO: FunctionExecutionResultMessage need not have 'name' field, changes to be made in API side
            return [
                {
                    "role": "function",
                    "content": content.content,
                    "name": "ToolAssistant"
                }
                for content in message.content
        ]

        else:
            raise ValueError(f"Error converting autogen message {asdict(message)}")

        return converted_msg

    @staticmethod
    def assert_valid_name(name: str) -> str:
        """
        Ensure that configured names are valid, raises ValueError if not.
        """
        if not re.match(r"^[a-zA-Z0-9_-]+$", name):
            raise ValueError(f"Invalid name: {name}. Only letters, numbers, '_' and '-' are allowed.")
        if len(name) > 64:
            raise ValueError(f"Invalid name: {name}. Name must be less than 64 characters.")
        return name

    def convert_tools(
            self,
            tools: Sequence[Tool | ToolSchema],
    ) -> List[ChatCompletionToolParam]:
        """
        Convert to the tools schema compatible with OpenAI
        """
        result: List[ChatCompletionToolParam] = [
            ChatCompletionToolParam(
                type="function",
                function=FunctionDefinition(
                    name=(tool.schema if isinstance(tool, Tool) else tool)["name"],
                    description=(tool.schema if isinstance(tool, Tool) else tool).get("description", ""),
                    parameters=cast(FunctionParameters, (tool.schema if isinstance(tool, Tool) else tool).get("parameters", {})),
                ),
            )
            for tool in tools
        ]
        
        # Check if all tools have valid names.
        for tool_param in result:
            self.assert_valid_name(tool_param["function"]["name"])
            
        return result
