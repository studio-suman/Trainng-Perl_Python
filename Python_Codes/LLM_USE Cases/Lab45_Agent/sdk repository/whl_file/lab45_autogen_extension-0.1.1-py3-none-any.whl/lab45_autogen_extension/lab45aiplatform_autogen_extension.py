import os
import asyncio
import json
from typing import Any, Mapping, Optional, Sequence, Union, AsyncGenerator
from typing_extensions import Unpack
from urllib.parse import urljoin
import aiohttp

from autogen_core import CancellationToken, FunctionCall
from autogen_core.models import (
    ChatCompletionClient, CreateResult, LLMMessage, ModelCapabilities, ModelInfo, RequestUsage
)
from autogen_core.tools import Tool, ToolSchema
from autogen_agentchat.state import BaseState

from lab45_autogen_extension.errors import Lab45AIPlatformRequestError, Lab45AIPlatformSQLStateStorageError
from lab45_autogen_extension.utils import (
    FINISH_REASONS, Lab45AIPlatformClientConfiguration, Lab45AIPlatformRequestUtils, ModelNames
)
from lab45_autogen_extension.sql_state_store import SQLiteStateStore
from lab45_autogen_extension.file_manager import FileManager

PLATFORM_COMPLETION_ENDPOINT = "skills/completion/query"
DEFAULT_SQL_STATE_STORAGE_DIR = os.getenv("DB_STATE_DIR", "db_state")

class Lab45AIPlatformCompletionClient(ChatCompletionClient):
    def __init__(self, **kwargs: Unpack[Lab45AIPlatformClientConfiguration]):
        """
        Initializes the Lab45AIPlatformClient, the model client extension for Lab45 AI platform.

        Args:
            **kwargs: Keyword arguments for configuration.
                - base_url (str): The base URL for the platform. Defaults to the environment variable 'LAB45AIPLATFORM_URL'.
                - api_key (str): The API key for authentication. Defaults to the environment variable 'LAB45AIPLATFORM_API_KEY'.
                - model_name (str): The name of the model to use. Defaults to 'gpt-4o'.

        Attributes:
            completion_url (str): The URL for the completion endpoint.
            laip_request_utils (Lab45AIPlatformRequestUtils): Utility for making requests to the platform.
            api_key (str): The API key for authentication, to be passed as arguments or set as an environment variable: 'LAB45AIPLATFORM_API_KEY'.
            model_name (str): The name of the model to use.
            stream_response (bool): Whether to stream the response. Defaults to False.
            return_usage_stats (bool): Whether to return usage statistics. Defaults to True.
            _total_usage (RequestUsage): Tracks the total usage of prompt and completion tokens.
            _actual_usage (RequestUsage): Tracks the actual usage of prompt and completion tokens.
        """
        self.base_url = kwargs.pop("base_url", os.getenv("LAB45AIPLATFORM_URL"))
        self.completion_url = urljoin(self.base_url,
                                      PLATFORM_COMPLETION_ENDPOINT)
        self.model_name = kwargs.pop("model_name", "gpt-4o")
        self.laip_request_utils = Lab45AIPlatformRequestUtils(self.completion_url, self.model_name)
        self.api_key = kwargs.pop("api_key", os.getenv("LAB45AIPLATFORM_API_KEY"))

        if self.model_name not in ModelNames._value2member_map_:
            raise ValueError(f"Invalid model name: {self.model_name}. Accepted values are: {list(ModelNames._value2member_map_)}")
        self.stream_response = False
        self.return_usage_stats = True
        # usage stats
        self._total_usage = RequestUsage(prompt_tokens=0, completion_tokens=0)
        self._actual_usage = RequestUsage(prompt_tokens=0, completion_tokens=0)

        self.sql_state_store = None

        self.file_manager = FileManager(base_url=self.base_url, api_key=self.api_key)
        # Initialize SQL state storage
        if kwargs.pop("enable_state_storage", False):
            os.makedirs(DEFAULT_SQL_STATE_STORAGE_DIR, exist_ok=True)
            db_path = os.path.join(DEFAULT_SQL_STATE_STORAGE_DIR, "state.db")
            self.sql_state_store = SQLiteStateStore(db_path)
    
    @staticmethod
    def _get_non_streaming_response_content(response_content):
        """
        Parse application/json response content for non-streaming completion requests.
        Return the content[string or tool response] and finish reason
        """
        content = response_content.get('content')
        tools_content = response_content.get('tools_content', [])
        
        if content:
            finish_reason = Lab45AIPlatformCompletionClient.convert_finish_reason("stop")
        else:
            content = [
                FunctionCall(
                    id=t_content["id"],
                    arguments=t_content["arguments"],
                    name=t_content["name"]
                ) for t_content in tools_content
            ]
            finish_reason = Lab45AIPlatformCompletionClient.convert_finish_reason("tool_calls")
        
        return content, finish_reason

    async def create(
            self,
            messages: Sequence[LLMMessage],
            tools: Sequence[Tool | ToolSchema]=None,
            json_output: Optional[bool] = None,
            extra_create_args: Mapping[str, Any]=None,
            cancellation_token: Optional[CancellationToken] = None,
        ) -> CreateResult:
        """
        Generates a non-streaming completion result for Lab45AIPlatformCompletionClient, using platform's API endpoints.
        """
        # convert messages
        laip_messages = []
        self.stream_response = False
        try:
            for m in messages:
                converted_msg = self.laip_request_utils.convert_autogen_message_to_laip_message(m)
                # If converted message is None, skip as message not compatible with platform schema (ex: FunctionCall in messages)
                if converted_msg is None:
                    continue
                if isinstance(converted_msg, list):
                    laip_messages.extend(converted_msg)
                else:
                    laip_messages.append(converted_msg)
        except Exception as e:
            raise Lab45AIPlatformRequestError(
                message=f"An error occurred during generating payload for non-streaming completion request with the platform: {str(e)}"
            )
        
        converted_tools = None
        if tools:
            #TODO: Implement tool schema conversion for Gemini family of models
            converted_tools = self.laip_request_utils.convert_tools(tools)

        payload = self.laip_request_utils.create_payload(messages=laip_messages, model_name=self.model_name, 
                                                         stream_response=self.stream_response, tool_schemas=converted_tools,
                                                         return_usage_stats=self.return_usage_stats)
        
        try:
            future = asyncio.ensure_future(self.laip_request_utils.completion_call(payload,
                                                                self.laip_request_utils.get_headers(self.api_key)))

            if cancellation_token is not None:
                await cancellation_token.link_future(future)
            response = await future

            # Get content[tool or string] and finish reason
            response_content = response['data']
            content, finish_reason = self._get_non_streaming_response_content(response_content)

            # Add usage stats
            usage_stats = response_content.get('usage_stats', {})
            usage = RequestUsage(
                prompt_tokens=usage_stats.get('prompt_tokens', 0),
                completion_tokens=usage_stats.get('completion_tokens', 0),
            )
            self._total_usage = self._add_usage(self._total_usage, usage)
            self._actual_usage = self._add_usage(self._actual_usage, usage)

            # Create final combined response
            response = CreateResult(
                finish_reason=finish_reason,
                content=content,
                usage=usage,
                cached=False,
            )

            return response
        except Exception as e:
            raise Lab45AIPlatformRequestError(
                message=f"An error occurred during the non-streaming completion request: {str(e)}"
            )

    async def create_stream(
            self,
            messages: Sequence[LLMMessage],
            tools: Sequence[Tool | ToolSchema] = None,
            json_output: Optional[bool] = None,
            extra_create_args: Mapping[str, Any] = None,
            cancellation_token: Optional[CancellationToken] = None,
    ) -> AsyncGenerator[Union[str, CreateResult], None]:
        """
        Generates a streaming completion result for Lab45AIPlatformCompletionClient, using platform's API endpoints.
        Note: Tool calls are always returned as a non-streaming response
        """
        try:
            # Convert messages to platform compatible format
            laip_messages = [
                converted_msg
                for m in messages
                for converted_msg in (
                    self.laip_request_utils.convert_autogen_message_to_laip_message(m)
                    if isinstance(self.laip_request_utils.convert_autogen_message_to_laip_message(m), list)
                    else [self.laip_request_utils.convert_autogen_message_to_laip_message(m)]
                )  if converted_msg
            ]
        except Exception as e:
            raise Lab45AIPlatformRequestError(
                message=f"An error occurred during generating payload for non-streaming completion request with the platform: {str(e)}"
            )

        self.stream_response = True

        # convert tools to compatible tool schemas
        converted_tools = (
            self.laip_request_utils.convert_tools(tools) if tools else None
        )

        # Create payload for streaming completion call
        payload = self.laip_request_utils.create_payload(
            messages=laip_messages,
            model_name=self.model_name,
            stream_response=self.stream_response,
            tool_schemas=converted_tools,
            return_usage_stats=self.return_usage_stats,
        )

        content_deltas = []
        request_usage_stats = None
        content = ""

        # make a call to Lab45 AI Platform completion API for streaming response
        async with aiohttp.ClientSession() as session:
            try:
                async with session.post(
                    self.laip_request_utils.request_url,
                    data=payload,
                    headers=self.laip_request_utils.get_headers(self.api_key),
                ) as response:
                    if response.status == 200:
                        if response.content_type == "text/event-stream":
                            # handle streaming responses
                            async for chunk in response.content:
                                for line in chunk.splitlines():
                                    decoded_chunk = json.loads(line.decode("utf-8"))
                                    data = decoded_chunk.get("data", {})
                                    if "content" in data:
                                        content_deltas.append(data["content"])
                                        yield data["content"]
                                    if "usage_stats" in data:
                                        request_usage_stats = data["usage_stats"]
                                        continue
                            finish_reason = Lab45AIPlatformCompletionClient.convert_finish_reason("stop")
                            if content_deltas:
                                content = "".join(content_deltas)
                        else:
                            # handle non-streaming json responses
                            response_json = await response.json()
                            response_content = response_json["data"]
                            content, finish_reason = self._get_non_streaming_response_content(response_content)
                            if "usage_stats" in response_content:
                                request_usage_stats = response_content["usage_stats"]
                    else:
                        raise Lab45AIPlatformRequestError(
                            message=f"Platform completion request for url: {self.laip_request_utils.request_url} failed with status: {response.status}"
                        )
            except Exception as e:
                raise Lab45AIPlatformRequestError(
                    message=f"Platform completion request for url: {self.laip_request_utils.request_url} failed with exception: {str(e)}"
                )

        # Add usage stats
        usage = RequestUsage(
            prompt_tokens=request_usage_stats.get("prompt_tokens", 0),
            completion_tokens=request_usage_stats.get("completion_tokens", 0),
        )
        self._total_usage = self._add_usage(self._total_usage, usage)
        self._actual_usage = self._add_usage(self._actual_usage, usage)

        # Create final combined response
        response = CreateResult(
            finish_reason=finish_reason,
            content=content,
            usage=usage,
            cached=False,
        )

        yield response

    def _ensure_state_store(self):
        """
        Ensures that the SQL state storage is initialized.
        Raises:
            Lab45AIPlatformSQLStateStorageError: If the state storage is not initialized.
        """
        if not self.sql_state_store:
            raise Lab45AIPlatformSQLStateStorageError(
                message="State storage not initialized, cannot store state"
            )

    def save_state(self, tenant_id: str, user_id: str, session_id: str, state: BaseState) -> bool:
        """
        Saves the given state to the SQL state storage.

        Args:
            tenant_id (str): The tenant identifier.
            user_id (str): The user identifier.
            session_id (str): The session identifier.
            state (BaseState): The state object to be stored.

        Returns:
            Any: The result of the state storage operation.

        Raises:
            Lab45AIPlatformSQLStateStorageError: If storing the state fails.
        """
        self._ensure_state_store()
        try:
            return self.sql_state_store.store_state(
                tenant_id=tenant_id, user_id=user_id, session_id=session_id, payload=state
            )
        except Exception as ex:
            raise Lab45AIPlatformSQLStateStorageError(
                message=f"Failed while storing state: {str(ex)}"
            )

    def load_state(self, tenant_id: str, user_id: str, session_id: str) -> BaseState:
        """
        Loads the latest state from the SQL state storage.

        Args:
            tenant_id (str): The tenant identifier.
            user_id (str): The user identifier.
            session_id (str): The session identifier.
            state (BaseState): The state object to be populated.

        Returns:
            Any: The retrieved state.

        Raises:
            Lab45AIPlatformSQLStateStorageError: If loading the state fails.
        """
        self._ensure_state_store()
        try:
            return self.sql_state_store.retrieve_latest_state(
                tenant_id=tenant_id, user_id=user_id, session_id=session_id
            )
        except Exception as ex:
            raise Lab45AIPlatformSQLStateStorageError(
                message=f"Failed while loading state: {str(ex)}"
            )

    def cleanup_state(self, tenant_id: str, user_id: str, session_id: str):
        """
        Cleans up the state for the given identifiers from the SQL state storage.

        Args:
            tenant_id (str): The tenant identifier.
            user_id (str): The user identifier.
            session_id (str): The session identifier.

        Returns:
            Any: The result of the cleanup operation.

        Raises:
            Lab45AIPlatformSQLStateStorageError: If cleaning up the state fails.
        """
        self._ensure_state_store()
        try:
            return self.sql_state_store.cleanup_state(
                tenant_id=tenant_id, user_id=user_id, session_id=session_id
            )
        except Exception as ex:
            raise Lab45AIPlatformSQLStateStorageError(
                message=f"Failed while cleaning up the state: {str(ex)}"
            )

    @staticmethod
    def _add_usage(usage1: RequestUsage, usage2: RequestUsage) -> RequestUsage:
        return RequestUsage(
            prompt_tokens=usage1.prompt_tokens + usage2.prompt_tokens,
            completion_tokens=usage1.completion_tokens + usage2.completion_tokens,
        )

    def actual_usage(self) -> RequestUsage:
        return self._actual_usage

    def total_usage(self) -> RequestUsage:
        return self._total_usage

    def count_tokens(self, messages: Sequence[LLMMessage], tools: Sequence[Tool | ToolSchema] = []) -> int:
        # TODO: Calculations to be done based on stats
        return 0

    def remaining_tokens(self, messages: Sequence[LLMMessage], tools: Sequence[Tool | ToolSchema] = []) -> int:
        # TODO: check for compatibility
        return 1

    @staticmethod
    def convert_finish_reason(finish_reason):
        return FINISH_REASONS[finish_reason]

    @property
    def capabilities(self) -> ModelCapabilities:
        return ModelCapabilities(
            vision=True,
            function_calling=True,
            json_output=True,
        )

    @property
    def model_info(self) -> ModelInfo:
        return ModelInfo(
            vision=True,
            function_calling=True,
            json_output=True,
            family="unknown",
        )

