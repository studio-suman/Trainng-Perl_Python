import asyncio
import os
import sys
from pathlib import Path

from autogen_agentchat.messages import MultiModalMessage
from autogen_agentchat.agents import AssistantAgent
from autogen_agentchat.messages import TextMessage
from autogen_core import CancellationToken, Image

sys.path.insert(0, os.path.abspath(os.getcwd()))
from lab45_autogen_extension.lab45aiplatform_autogen_extension import Lab45AIPlatformCompletionClient

os.environ["LAB45AIPLATFORM_URL"] = "http://localhost:8000/v1.1/"
os.environ["LAB45AIPLATFORM_API_KEY"] = "<api-key>"

# Create a Lab45 AI Platform completion client
lab45_client = Lab45AIPlatformCompletionClient(
        model_name='gpt-4o'
    )


async def assistant_chat_with_platform_client_non_streaming():
    """
    Non-streaming
    Create an assistant agent that interacts with the Lab45 AI Platform completion lab45_client.
    """
    agent = AssistantAgent(
        name="assistant",
        model_client=lab45_client,
        system_message="Your name is AutogenAssist, you are a general purpose AI assistant which can help with user queries"
    )

    # Non-Streaming
    response = await agent.on_messages(
        [TextMessage(content="What is your name?", source="user")],
        cancellation_token=CancellationToken(),
    )
    print(response.chat_message)


async def assistant_chat_with_platform_client_streaming():
    """
    Streaming
    Create an assistant agent that interacts with the Lab45 AI Platform completion lab45_client and generates a streaming response.
    """
    agent = AssistantAgent(
        name="assistant",
        model_client=lab45_client,
        system_message="Your name is AutogenAssist, you are a general purpose AI assistant which can help with user queries",
        model_client_stream=True  # Keep this as True for streaming responses
    )

    # Streaming
    async for message in agent.on_messages_stream(
            [TextMessage(content="What is your name?", source="user")],
            cancellation_token=CancellationToken(),
    ):
        print(message)


async def assistant_chat_with_platform_client_multimodal_file():
    """
    Create a multi modal assistant agent that interacts with the Lab45 AI Platform completion client
    by passing an image and query as input.
    """
    agent = AssistantAgent(
        name="assistant",
        system_message="You are a helpful assistant.",
        model_client=lab45_client,
        model_client_stream=False
    )

    cancellation_token = CancellationToken()

    # create a multi modal message with a local image uploaded
    message = MultiModalMessage(
        content=["Give a summary of this image:", Image.from_file(Path("/Users/356979wipro_lab45/Downloads/gfvz7mXZkW.jpg"))],
        source="user",
    )
    response = await agent.on_messages([message], cancellation_token)
    print(response)


async def assistant_chat_with_platform_client_multimodal_url():
    """
    Create a multi modal assistant agent that interacts with the Lab45 AI Platform completion client
    by fetching an image from a URL and passing it as input.
    """
    agent = AssistantAgent(
        name="assistant",
        system_message="You are a helpful assistant.",
        model_client=lab45_client,
        model_client_stream=True
    )

    from autogen_core import Image
    from PIL import Image as PILImage
    import aiohttp

    async def from_url(url: str) -> Image:
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as response:
                content = await response.read()
                return Image.from_pil(PILImage.open(content))

    image = await from_url("https://upload.wikimedia.org/wikipedia/commons/3/3e/W3Schools_logo.png")

    # create a multi modal message with a local image uploaded
    message = MultiModalMessage(
        content=["Give a summary of this image:", image],
        source="user",
    )

    # Streaming
    async for message in agent.on_messages_stream(
            [message],
            cancellation_token=CancellationToken(),
    ):
        print(message)


if __name__ == "__main__":
    asyncio.run(assistant_chat_with_platform_client_non_streaming())