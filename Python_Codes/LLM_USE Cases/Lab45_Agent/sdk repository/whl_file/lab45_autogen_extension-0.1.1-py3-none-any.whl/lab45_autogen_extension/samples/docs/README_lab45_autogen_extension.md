# Lab45 AI Platform Autogen extension

This package introduces an extension to the Autogen 0.4 agents framework.
Following Lab45 AI Platform specific extensions have been added:
- A custom `Lab45AIPlatform` model client class which internally routes all LLM and tool based calls to platform's backend APIs. 
- A catalog of tools available with the platform, which can be consumed by this extended library
- Platform's RAG capability has been made available using customs tools.
- Multi-modal support (limited to images)

With this extended library, users can use most of the features that Autogen offers, all the while leveraging the the Lab45 AI Platform's backend APIs, models and tools.

## Installation and requirements
It is recommended to create a seperate virtual environment with python version `3.11.x`. 
Use the package manager [pip](https://pip.pypa.io/en/stable/) to install the extension package using the .whl file.

```bash
pip install lab45_autogen_extension-0.1.0-py3-none-any.whl
```

The .whl file will also install dependencies: Autogen 0.4, Langchain experimental and OpenAI. Post installation, please ensure these packages match below mentioned versions:
`autogen-agentchat==0.4.5`
`autogen-core==0.4.5`
`autogen-ext==0.4.5`
`openai~=1.51.1`

## Model Client Usage
In order to use this model client class with existing Autogen functionalities, the users post installation of this extended library, need to initialize the Lab45AIPlatformCompletionClient class with the right `LAB45AIPLATFORM_URL` and `LAB45AIPLATFORM_API_KEY` (either passed as arguments or as environment variables).

```python
os.environ["LAB45AIPLATFORM_URL"] = "https://api.lab45.ai/v1.1/"
os.environ["LAB45AIPLATFORM_API_KEY"] = "your_api_key_here"  # Platform API key or Bearer token
```

This model client class can be imported from the `lab45aiplatform_autogen_extension` module and the object can then be added to the model_client field of any agent or team created using Autogen.

```python
from autogen_extension.lab45aiplatform_autogen_extension import Lab45AIPlatformCompletionClient

client = Lab45AIPlatformCompletionClient(
        model_name='gpt-4'
    )

agent = AssistantAgent(
        name="assistant",
        model_client=client,
        system_message="Your name is AutogenAssist, you are a general purpose AI assistant which can help with user queries"
    )
```

## Tools Usage
The lab45_autogen_extension library allows users to make use of various different type of tools:
1. The catalog of tools available in the platform can be accessed using `lab45_autogen_extension.custom_tools`. The `imagetools.Lab45AIPlatformText2ImageTool` can take in either `dalle` or `stablediffusion` as options for image models. 
```python
from lab45_autogen_extension.custom_tools.imagetools import Lab45AIPlatformText2ImageTool
image_tool = LangChainToolAdapter(Lab45AIPlatformText2ImageTool('dalle'))
```
List of platform tools available: `Lab45AIPlatformText2ImageTool, Lab45AIPlatformBingSearchTool, Lab45AIPlatformSlideGenerationTool`

2. Any Langchain tool can be passed as a tool.
```python
from langchain_experimental.tools.python.tool import PythonAstREPLTool
tool = LangChainToolAdapter(PythonAstREPLTool(locals={"df": df}))
```

3. Any custom function can be passed as a tool to the agent. The Autogen function: `FunctionTool` can be used for this purpose. 
```python
def arxiv_search(query: str, max_results: int = 1) -> str:
    pass
arxiv_search_tool = FunctionTool(arxiv_search, description="Search Arxiv for papers related to a given topic, including abstracts")
```

## RAG/Doc-completion Usage:
The platform's RAG feature has been extended to this library in the form of a tool: `Lab45AIPlatformRAGTool`. The files and documents will have to be pre-indexed using the dataset and doc_completion endpoints. The `dataset_id` along with `message_history`, if required will be passed to this tool and finally `doc_completion query` endpoint be called to fetch responses based on documents indexed.
```python
from lab45_autogen_extension.custom_tools.ragtool import Lab45AIPlatformRAGTool
rag_tool = LangChainToolAdapter(Lab45AIPlatformRAGTool(dataset_id="<dataset_id>", model_name="gpt-4o", top_k=30))
```

## Multi-modal Agents:
The platform's multi-modal capability of using images for completion queries can be leveraged using Autogen's `MultiModalMessage` class. 
```python
message = MultiModalMessage(
        content=["Give a summary of this image:", Image.from_file(Path("gfvz7mXZkW.jpg"))],
        source="user",
    )
```