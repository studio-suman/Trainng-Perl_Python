# Dynamic Data Attachment Using Lab45 AI Platform API

This document provides a guide on utilizing a Lab45 AI Platform API implementation to augment the contextual data used by a Retrieval-Augmented Generation (RAG) agent. This approach dynamically attaches extra document data alongside the pre-existing, vectored data within a Lab45 AI platform dataset. This technique enables you to query and receive precise, combined responses that leverage information from both the dataset and an external PDF document, using a direct API call.

## Extract Text from PDF Document:

This section reads a PDF file and extracts its textual content.

```python
from pypdf import PdfReader
pdf_file_path = "path/to/your/document.pdf"
pdf_text = ""
with open(pdf_file_path, 'rb'):
    reader = PdfReader(pdf_file_path)
    for page in reader.pages:
        pdf_text += page.extract_text() or ""
```

## Preparing Payload and header for the API Call:

Preparing URL, playload and header to call the Lab45 AI Platform API.

```python
token = "User Token or API Key"
url = "<<Base_URL>>/v1.1/skills/doc_completion/query"
payload = {
    "dataset_id": "fc487d2d-8b81-4cb7-9243-1e0bb6694df1", # Replace with your actual dataset ID
    "skill_parameters": {
        "model_name": "gpt-4o",
        "temperature": 0,
        "max_output_tokens": 4000,
        "return_sources":False
    },
    "stream_response": False,
    "messages": [
        {
            "content": pdf_text,
            "role": "user"
        },
        {
            "content": "Based on the context provided, tell me about 'The Impact of Football on Society' and 'The FIFA World Cup'",
            "role": "user"
        }
    ]
}
headers = {
    'Content-Type': 'application/json',
    'Authorization': 'bearer ' + token
}
```

## Quering on the context present in Dataset and PDF file::

Calling Lab45 AI Platform API with the Dataset details and PDF content to answer queries.

```python
import requests
import json
response = requests.post(url, headers=headers, data=json.dumps(payload))
response_json = response.json()
```