# Custom Agent Transitions using LAB45 AI Platform APIs

This document explains how to create and manage a workflow with custom transitions between AI agents using the LAB45 AI platform APIs. Custom transitions allow agents to communicate with each other in a structured way, following a pre-defined workflow that directs the conversation between specialized agents.

## Overview

The LAB45 platform supports creating teams of specialized agents that can work together to solve complex problems. By defining custom transitions, you can control how messages flow between agents, allowing for sophisticated multi-agent collaboration patterns.

This implementation demonstrates:

1. Creating specialized agents with specific roles
2. Defining a transition graph that determines the allowed communication paths
3. Creating a team with a custom transition workflow
4. Starting and managing chat sessions with the team

## Specialized Agents

Our example creates a team of five specialized agents that work together on software development projects:

1. **Project Manager**: Creates detailed project plans with task breakdown and timeline estimates
2. **System Architect**: Designs robust system architectures with technical specifications
3. **Developer**: Implements code based on specifications with realistic time estimates
4. **Reviewer**: Evaluates code quality using structured assessment frameworks
5. **Tester**: Verifies functionality with comprehensive testing methodologies

### Agent Creation

The following code snippet demonstrates how agents are configured with specialized instructions:

Following request shows an example of a particular use-case.
Create Project manager agent

`HTTP Request`
```bash
POST /v1.1/agents HTTP/1.1
Content-Type: application/json
Accept: text/event-stream, application/json
Authorization: Bearer `<api_key>`
Host: devapi.lab45.ai
Content-Length: 148
```
```json

{
	"allow_all_access": false,
	"dataset_id": null,
	"description": "You are the Project manager for a Team",
	"instructions": "You are an experienced project manager who excels at creating detailed project plans.\\nYour responsibilities include:\\n1. Gathering and analyzing requirements\\n2. Breaking down work into specific tasks with time estimates (in days)\\n3. Creating a timeline with clear dependencies between tasks\\n4. Assigning resource requirements for each task\\n5. Identifying risks and mitigation strategies\\n6. Defining project milestones and deliverables\\n7. Providing regular status updates and timeline adjustments\\n\\nAlways create detailed plans with specific day estimates for each task.",
	"max_output_tokens": 1500,
	"model_name": "gpt-4o",
	"name": "project_manager_test",
	"temperature": 0,
	"tools": [],
	"type": "Basic"
}
```
`Response`
```json
{
	"_id": "fe7d7fb0-1190-441e-b890-26da7a563c22",
	"allow_all_access": false,
	"dataset_id": null,
	"description": "You are responsible for terminating the conversation.",
	"instructions": "sane instruction which we sent while we creating agent",
	"max_output_tokens": 100,
	"model_name": "gpt-4o",
	"name": "terminator_test",
	"owners": [
		"XXXXXXX-92af-4379-8bb8-XXXXXXX"
	],
	"temperature": 0,
	"tenant_id": "XXXXXXX-8b7c-43fb-8119-XXXXXXXXX",
	"tools": [],
}
```
## Create other agent with instructions provided below:

**System Architect**:

```json
{
"name": "system_architecture_test"
"description":"You are a senior software architect designing robust systems."
"instructions": "You are a senior software architect who designs robust system architectures.\\nFor each component you design, provide:\\n1. Technical specifications with implementation complexity (Low/Medium/High)\\n2. Estimated development time in days\\n3. Required technical skills\\n4. Dependencies and integration points\\n5. Scalability and performance considerations\\n6. Technology recommendations with justifications"
...
}
```

**Developer**:
```json
{
    "name": "developer_test"
    "description": "You are a skilled developer who writes code based on provided specifications."
    "instructions": "You are a skilled developer who implements code based on specifications.\\nFor each implementation task, provide:\\n1. Time estimates for development in days (be realistic)\\n2. Technical challenges you anticipate\\n3. Required libraries and dependencies\\n4. Testing approach for your implementation\\n5. Resource needs (computing, specialized knowledge, etc.)"
    ...
}
```

**Reviewer**:
```json
{
"name": "reviewer_test"
"description": "You are a meticulous code reviewer who evaluates code quality and ensures adherence to standards and best practices."
"instructions": "You are a meticulous code reviewer who evaluates code quality.\\nFor each review, provide:\\n1. Time needed for thorough review (in days)\\n2. Quality assessment framework you'll use\\n3. Critical aspects you'll focus on during review\\n4. Standards and best practices you'll check against"
}
```

**Tester**:
```json
{
"name": "tester_test"
"description": "You are a comprehensive software tester who verifies functionality and ensures software quality through various testing methodologies"
"instructions":
"You are a comprehensive software tester who verifies functionality.\\nFor each testing phase, provide:\\n1. Time required for complete test coverage (in days)\\n2. Test strategy (manual, automated, types of testing)\\n3. Test environment requirements\\n4. Test data needs\\n5. Success criteria for passing tests\\n6. Known edge cases you'll specifically test"
}
```
## Python request

`Python Request`
```python
import requests  # Import the requests module to send HTTP requests

# Define the API endpoint for querying the document completion skill
agent_endpoint = f"https://devapi.lab45.ai/v1.1/agents"

# Set the headers for the request, including content type, accepted response format, and authorization token
headers = {
    'Content-Type': "application/json",  # The content type of the request is JSON, meaning the request body will be in JSON format
    'Accept': "text/event-stream, application/json",  # The server is expected to respond with either event-stream or JSON
    'Authorization': "Bearer <api_key>"  # Replace <api_key> with your actual API key for authentication
}

# Define the payload (request body) for the API call, which contains the user's query and skill parameters
payload = {
	"allow_all_access": false,
	"dataset_id": null,
	"description": "You are the Project manager for a Team",
	"instructions": "You are an experienced project manager who excels at creating detailed project plans.\\nYour responsibilities include:\\n1. Gathering and analyzing requirements\\n2. Breaking down work into specific tasks with time estimates (in days)\\n3. Creating a timeline with clear dependencies between tasks\\n4. Assigning resource requirements for each task\\n5. Identifying risks and mitigation strategies\\n6. Defining project milestones and deliverables\\n7. Providing regular status updates and timeline adjustments\\n\\nAlways create detailed plans with specific day estimates for each task.",
	"max_output_tokens": 1500,
	"model_name": "gpt-4o",
	"name": "project_manager_test",
	"temperature": 0,
	"tools": [],
	"type": "Basic"
}

response = requests.post(agent_endpoint, headers=headers, json=payload)

# Print the response from the API call to inspect the result (status code, content, etc.)
print(response)
```
## Note: Record _id field which is agent_id, it requires when we create the team

## Agent Transition Workflow Graph Structure

Transition: Each agent can only pass control to the next agent or choose from the list of agent in the sequence, enforcing a structured workflow where each specialist provides their input at the appropriate stage of the process.

The transition graph is defined as a dictionary where each key represents a source node (agent) and the value is a list of target nodes to which that agent can transition. In our implementation, we've defined a linear workflow:

```python
graph_dict = {}
graph_dict[initial_state] = [project_manager_test]
graph_dict[project_manager_test] = [architect_test]
graph_dict[architect_test] = [developer_test]
graph_dict[developer_test] = [reviewer_test]
graph_dict[reviewer_test] = [tester_test]
```
## Visualizing the Transition Graph

Initial State → Project Manager → System Architect → Developer → Reviewer→ Tester

This linear workflow ensures that:

The Project Manager first creates the project plan
The System Architect then designs the technical architecture
The Developer provides implementation details
The Reviewer evaluates the proposed implementation
The Tester plans testing strategies and validation approaches

More complex workflows could include branching paths, feedback loops, or parallel processes by adding additional transitions in the graph dictionary.

## Creation of Team: 

**PreRequisite**:

Agent name and agent _id, which you got from agent create api response.

**Workflow configuration**:
When creating a team with custom transitions, you need to specify the workflow pattern using agent UUIDs rather than their names. This is done through a transition graph in the team creation payload.

### Transition Graph with UUIDs

The transition graph is a JSON structure that defines which agents can pass control to which others:


```json
"workflow": {
  "transition_graph": {
    "initial_state": ["c2c5929e-f51b-4e71-a370-cc6279bea38b"],  // User Query → Project Manager
    "c2c5929e-f51b-4e71-a370-cc6279bea38b": ["dc9d5954-be19-4aaa-8b89-aec4db87e75b"],   // Project Manager → System Architect  
    "dc9d5954-be19-4aaa-8b89-aec4db87e75b": ["64b31edd-61c2-4046-84c9-ce8cfec1835e"],  // System Architect → Developer
    "64b31edd-61c2-4046-84c9-ce8cfec1835e": ["3da96cd0-d1ad-42e5-9ea9-8e6852e48c67"],   // Developer → Reviewer
    "3da96cd0-d1ad-42e5-9ea9-8e6852e48c67": ["0fbe0d2e-d7ab-4704-8df9-40b8d7ac3e1c"]   // Reviewer → Tester
  },
  "transition_type": "allowed" 
}
```

## Request sample to create the team with agents.

`HTTP Request`
```bash
POST /v1.1/teams HTTP/1.1
Content-Type: application/json
Accept: text/event-stream, application/json
Authorization: Bearer `<api_key>`
Host: devapi.lab45.ai
Content-Length: 148
```
```json

{
  "allow_all_access": false,
  "assistant_ids": ["c2c5929e-f51b-4e71-a370-cc6279bea38b","dc9d5954-be19-4aaa-8b89-aec4db87e75b","64b31edd-61c2-4046-84c9-ce8cfec1835e",
  "3da96cd0-d1ad-42e5-9ea9-8e6852e48c67","0fbe0d2e-d7ab-4704-8df9-40b8d7ac3e1c"],
  "description": "Project planner Team",
  "instructions": "You have to plan the project based on the query",
  "name": "project_plan_team_test",
  "workflow": {
    "transition_graph": {
    "initial_state": ["c2c5929e-f51b-4e71-a370-cc6279bea38b"], 
    "c2c5929e-f51b-4e71-a370-cc6279bea38b": ["dc9d5954-be19-4aaa-8b89-aec4db87e75b"],  
    "dc9d5954-be19-4aaa-8b89-aec4db87e75b": ["64b31edd-61c2-4046-84c9-ce8cfec1835e"],  
    "64b31edd-61c2-4046-84c9-ce8cfec1835e": ["3da96cd0-d1ad-42e5-9ea9-8e6852e48c67"],
    "3da96cd0-d1ad-42e5-9ea9-8e6852e48c67": ["0fbe0d2e-d7ab-4704-8df9-40b8d7ac3e1c"],
    },
    "transition_type" : "allowed" 
	}
}
```
`Response`
```json
{
	"_id": "fe7d7fb0-1190-441e-b890-26da7a563c22",
    ...
}	
```

`Python Request`
```python
import requests  # Import the requests module to send HTTP requests

# Define the API endpoint for querying the document completion skill
team_endpoint = f"https://devapi.lab45.ai/v1.1/teams"

# Set the headers for the request, including content type, accepted response format, and authorization token
headers = {
    'Content-Type': "application/json",  # The content type of the request is JSON, meaning the request body will be in JSON format
    'Accept': "text/event-stream, application/json",  # The server is expected to respond with either event-stream or JSON
    'Authorization': "Bearer <api_key>"  # Replace <api_key> with your actual API key for authentication
}

# Define the payload (request body) for the API call, which contains the user's query and skill parameters
payload = {
	"allow_all_access": false,
  "assistant_ids": ["c2c5929e-f51b-4e71-a370-cc6279bea38b","dc9d5954-be19-4aaa-8b89-aec4db87e75b","64b31edd-61c2-4046-84c9-ce8cfec1835e",
  "3da96cd0-d1ad-42e5-9ea9-8e6852e48c67","0fbe0d2e-d7ab-4704-8df9-40b8d7ac3e1c"],
  "description": "Project planner Team",
  "instructions": "You have to plan the project based on the query",
  "name": "project_plan_team_test",
  "workflow": {
    "transition_graph": {
    "initial_state": ["c2c5929e-f51b-4e71-a370-cc6279bea38b"], 
    "c2c5929e-f51b-4e71-a370-cc6279bea38b": ["dc9d5954-be19-4aaa-8b89-aec4db87e75b"],  
    "dc9d5954-be19-4aaa-8b89-aec4db87e75b": ["64b31edd-61c2-4046-84c9-ce8cfec1835e"],  
    "64b31edd-61c2-4046-84c9-ce8cfec1835e": ["3da96cd0-d1ad-42e5-9ea9-8e6852e48c67"],
    "3da96cd0-d1ad-42e5-9ea9-8e6852e48c67": ["0fbe0d2e-d7ab-4704-8df9-40b8d7ac3e1c"],
    },
    "transition_type" : "allowed" 
	}
}

response = requests.post(team_endpoint, headers=headers, json=payload)

# Print the response from the API call to inspect the result (status code, content, etc.)
print(response)
```

## Note: Record the _id which is team id from the response, it will be used later for teams chat.


## Teams Chat

Now user can initiate the chat with the team created.

`HTTP Request`
```bash
POST /v1.1/agent_chat_session/query HTTP/1.1
Content-Type: application/json
Accept: text/event-stream, application/json
Authorization: Bearer `<api_key>`
Host: devapi.lab45.ai
Content-Length: 148
```
```json

{
  "conversation_id":"67d2913af0a3e3549a044e0b",
		"party_id": "75e38237-b8f6-4510-808c-8c44a54e2cd1",
  "party_type": "Team",
  "stream_response": false,
	"max_rounds" :25,

  "messages": [
    {
      "role": "user",
      "name": "user",
      "content":  " I need a customer relationship management (CRM) system with the following requirements:\n    \n    1. User management with role-based access control (admin, manager, sales rep)\n    2. Customer database with contact information, communication history, and purchase records\n    3. Sales pipeline management with deal tracking and forecasting\n    4. Email integration for tracking client communications\n    5. Reporting dashboard with customizable KPIs\n    6. Mobile app for on-the-go access\n    7. API for integration with our existing accounting software\n    \n    Our target launch is in 4 months and we have a team of 3 developers available.\n    Please create a detailed project plan with timeline estimates for each phase.\n    "
    }
  ],
  "save_conversation": true
}
```
`Response`
```json
{
{
	"data": {
		"content": "To develop a CRM system with the specified requirements, we will break down the project into phases and tasks, estimate the time required for each task, and create a timeline. Given the 4-month target launch and a team of 3 developers, we will need to prioritize tasks and manage resources efficiently.\n\n### Phase 1: Requirements Gathering and Analysis (5 days)\n- **Task 1.1:** Conduct stakeholder interviews and workshops (2 days)\n- **Task 1.2:** Document detailed functional and non-functional requirements (3 days)\n\n### Phase 2: System Design (10 days)\n- **Task 2.1:** Design system architecture and database schema (4 days)\n- **Task 2.2:** Create wireframes and UI/UX design for web and mobile (3 days)\n- **Task 2.3:** Define API specifications for integration (3 days)\n\n### Phase 3: Development (50 days)\n- **Task 3.1:** Develop user management module with role-based access (8 days)\n- **Task 3.2:** Implement customer database and contact management (10 days)\n- **Task 3.3:** Develop sales pipeline management features (10 days)\n- **Task 3.4:** Integrate email tracking functionality (7 days)\n- **Task 3.5:** Create reporting dashboard with customizable KPIs (8 days)\n- **Task 3.6:** Develop mobile app for on-the-go access (7 days)\n\n### Phase 4: Integration and Testing (15 days)\n- **Task 4.1:** Integrate CRM with existing accounting software via API (5 days)\n- **Task 4.2:** Conduct unit and integration testing (5 days)\n- **Task 4.3:** Perform user acceptance testing (5 days)\n\n### Phase 5: Deployment and Launch (5 days)\n- **Task 5.1:** Deploy CRM system to production environment (2 days)\n- **Task 5.2:** Conduct training sessions for end-users (3 days)\n\n### Phase 6: Post-Launch Support and Optimization (5 days)\n- **Task 6.1:** Monitor system performance and address any issues (3 days)\n- **Task 6.2:** Gather user feedback and implement minor improvements (2 days)\n\n### Timeline and Dependencies\n- **Month 1:** Complete Phases 1 and 2\n- **Month 2 and 3:** Focus on Phase 3 (Development)\n- **Month 4:** Complete Phases 4, 5, and 6\n\n### Resource Allocation\n- Each developer will be assigned tasks based on their expertise, ensuring parallel development where possible to meet the timeline.\n\n### Risks and Mitigation Strategies\n- **Risk:** Delays in requirements gathering\n  - **Mitigation:** Schedule regular check-ins with stakeholders\n- **Risk:** Integration challenges with existing software\n  - **Mitigation:** Allocate additional buffer time for integration tasks\n\n### Milestones and Deliverables\n- **Milestone 1:** Completion of system design (End of Month 1)\n- **Milestone 2:** Completion of core development (End of Month 3)\n- **Milestone 3:** Successful deployment and user training (End of Month 4)\n\nPlease review the plan and let me know if there are any adjustments or additional requirements.",
		"conversation_id": "67d2913af0a3e3549a044e0b",
		"name": "project_manager_test",
		"role": "assistant",
		"response_status": "Pending"
	}
}
}	
```

`Python Request`
```python
import requests  # Import the requests module to send HTTP requests

# Define the API endpoint for querying the document completion skill
chat_endpoint = f"https://devapi.lab45.ai/v1.1/agent_chat_session/query"

# Set the headers for the request, including content type, accepted response format, and authorization token
headers = {
    'Content-Type': "application/json",  # The content type of the request is JSON, meaning the request body will be in JSON format
    'Accept': "text/event-stream, application/json",  # The server is expected to respond with either event-stream or JSON
    'Authorization': "Bearer <api_key>"  # Replace <api_key> with your actual API key for authentication
}

# Define the payload (request body) for the API call, which contains the user's query and skill parameters
payload = {
  "conversation_id":"67d2913af0a3e3549a044e0b",
		"party_id": "75e38237-b8f6-4510-808c-8c44a54e2cd1",
  "party_type": "Team",
  "stream_response": false,
	"max_rounds" :25,

  "messages": [
    {
      "role": "user",
      "name": "user",
      "content":  " I need a customer relationship management (CRM) system with the following requirements:\n    \n    1. User management with role-based access control (admin, manager, sales rep)\n    2. Customer database with contact information, communication history, and purchase records\n    3. Sales pipeline management with deal tracking and forecasting\n    4. Email integration for tracking client communications\n    5. Reporting dashboard with customizable KPIs\n    6. Mobile app for on-the-go access\n    7. API for integration with our existing accounting software\n    \n    Our target launch is in 4 months and we have a team of 3 developers available.\n    Please create a detailed project plan with timeline estimates for each phase.\n    "
    }
  ],
  "save_conversation": true
}

response = requests.post(chat_endpoint, headers=headers, json=payload)

# Print the response from the API call to inspect the result (status code, content, etc.)
print(response)
```

## Chat Session Polling Mechanism

The LAB45 platform uses a polling mechanism for agent chat sessions. When you initiate a chat session with a team, the process works as follows:

### Initial Request

Your first API call starts the conversation and returns a response with:
- A `conversation_id` to track this specific chat session
- A `response_status` typically set to "Pending"

## Polling for Completion
Since agent responses may take time (especially in multi-agent scenarios), you need to poll the same endpoint repeatedly until the process completes:

Take the conversation_id from the initial response
Include it in subsequent requests to the same endpoint
Continue polling until response_status changes to "Completed"


```python

# Polling request (includes conversation_id from initial response)
chat_payload = {
    "conversation_id": "67d1960af0a3e3549a044dc6",  # From initial response
    "party_id": team_id,
    "party_type": "Team",
    "stream_response": False,
    "max_rounds": 25,
    "messages": [...],  # Same messages as before
    "save_conversation": True
}

# Implementation of polling loop
while chat_data['data']['response_status'] != "Completed":
    print("Response still pending. Polling in 2 seconds...")
    time.sleep(2)  # Wait before polling again
    
    response = requests.post(url, headers=headers, json=chat_payload)
    chat_data = response.json()
    print(f"Status: {chat_data['data']['response_status']}")

```

## Observing the Transition Pattern in Action

When running a chat session with your multi-agent team, you'll notice that the responses follow the exact transition pattern defined in your graph. The conversation will progress through each agent in the specified sequence:

1. Your initial user query goes to the **Project Manager**
2. The Project Manager's response is followed by the **System Architect**
3. The System Architect is followed by the **Developer**
4. The Developer is followed by the **Reviewer**
5. Finally, the Reviewer is followed by the **Tester**

This structured flow ensures that each specialist contributes their expertise at the appropriate stage of the process, creating a comprehensive solution that benefits from multiple perspectives. The LAB45 platform handles all the transitions behind the scenes, making the experience seamless for the end user.

> **Key Insight**: By monitoring the `name` field in each response during polling, you can track which agent is currently active in the workflow.
