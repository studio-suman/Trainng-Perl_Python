
import os
import sys
import asyncio
from autogen_agentchat.agents import AssistantAgent
from autogen_core.tools import FunctionTool
from autogen_agentchat.ui import Console
from autogen_agentchat.conditions import TextMentionTermination, MaxMessageTermination, HandoffTermination
from autogen_agentchat.teams import RoundRobinGroupChat, SelectorGroupChat, Swarm
from autogen_agentchat.messages import HandoffMessage

sys.path.insert(0, os.path.abspath(os.getcwd()))
from lab45_autogen_extension.lab45aiplatform_autogen_extension import Lab45AIPlatformCompletionClient

os.environ["LAB45AIPLATFORM_URL"] = "http://localhost:8000/v1.1/"
os.environ["LAB45AIPLATFORM_API_KEY"] = "<api-key>"

# Create a Lab45 AI Platform completion client
lab45_client = Lab45AIPlatformCompletionClient(
        model_name='gpt-4o'
    )

"""
Using RoundRobin GroupChat: The agents respond in a round robin fashion based on the order specified.
"""
async def team_roundrobin_groupchat_with_platform_client():
    """
    Non-streaming
    Create a team of agents that interact with the Lab45 AI Platform completion client.
    """

    primary_agent = AssistantAgent(
        name="assistant",
        model_client=lab45_client,
        model_client_stream=False,
        system_message="Your name is AutogenAssist, you are a general purpose AI assistant which can help with user queries",
    )

    critic_agent = AssistantAgent(
        "critic",
        model_client=lab45_client,
        system_message="Provide constructive feedback. Respond with 'APPROVE' to when your feedbacks are addressed.",
    )

    # Define a termination condition that stops the task if the critic approves.
    text_termination = TextMentionTermination("APPROVE")

    team = RoundRobinGroupChat([primary_agent, critic_agent], termination_condition=text_termination)
    
    response = await team.run(task="write a short poem about the fall season")
    print(response)

"""
Using Selector GroupChat: Allowing a 'Group Chat Manager' will LLM backend
to decide on the next speaker(agent) based on the task.
"""
def search_web_tool(query: str) -> str:
    # Uses mock tools instead of real APIs for demonstration purposes
    if "2006-2007" in query:
        return """Here are the total points scored by Miami Heat players in the 2006-2007 season:
        Udonis Haslem: 844 points
        Dwayne Wade: 1397 points
        James Posey: 550 points
        ...
        """
    elif "2007-2008" in query:
        return "The number of total rebounds for Dwayne Wade in the Miami Heat season 2007-2008 is 214."
    elif "2008-2009" in query:
        return "The number of total rebounds for Dwayne Wade in the Miami Heat season 2008-2009 is 398."
    return "No data found."


def percentage_change_tool(start: float, end: float) -> float:
    return ((end - start) / start) * 100

async def team_selector_groupchat_with_platform_client():
    """
    Non-streaming
    Create a team of agents that interact with the Lab45 AI Platform completion client using an LLM based slector to choose the next speaker agent.
    """

    search_tool = FunctionTool(search_web_tool, description="For searching information on the web")
    percentage_tool = FunctionTool(percentage_change_tool, description="For performing percentage change calculations")

    planning_agent = AssistantAgent(
        "PlanningAgent",
        description="An agent for planning tasks, this agent should be the first to engage when given a new task.",
        model_client=lab45_client,
        system_message="""
        You are a planning agent.
        Your job is to break down complex tasks into smaller, manageable subtasks.
        Your team members are:
            WebSearchAgent: Searches for information
            DataAnalystAgent: Performs calculations

        You only plan and delegate tasks - you do not execute them yourself.

        When assigning tasks, use this format:
        1. <agent> : <task>

        After all tasks are complete, summarize the findings and end with "TERMINATE".
        """,
    )

    web_search_agent = AssistantAgent(
        "WebSearchAgent",
        description="An agent for searching information on the web.",
        tools=[search_tool],
        model_client=lab45_client,
        system_message="""
        You are a web search agent.
        Your only tool is search_tool - use it to find information.
        You make only one search call at a time.
        Once you have the results, you never do calculations based on them.
        """,
    )

    data_analyst_agent = AssistantAgent(
        "DataAnalystAgent",
        description="An agent for performing calculations.",
        model_client=lab45_client,
        tools=[percentage_tool],
        system_message="""
        You are a data analyst.
        Given the tasks you have been assigned, you should analyze the data and provide results using the tools provided.
        If you have not seen the data, ask for it.
        """,
    )

    text_mention_termination = TextMentionTermination("TERMINATE")
    max_messages_termination = MaxMessageTermination(max_messages=25)
    termination = text_mention_termination | max_messages_termination

    selector_prompt = """Select an agent to perform task.
        {roles}

        Current conversation context:
        {history}

        Read the above conversation, then select an agent from {participants} to perform the next task.
        Make sure the planner agent has assigned tasks before other agents start working.
        Only select one agent.
        """
    
    team = SelectorGroupChat(
        [planning_agent, web_search_agent, data_analyst_agent],
        model_client=lab45_client,
        termination_condition=termination,
        selector_prompt=selector_prompt,
        allow_repeated_speaker=True,  # Allow an agent to speak multiple turns in a row.
    )
    task = "Who was the Miami Heat player with the highest points in the 2006-2007 season, and what was the percentage change in his total rebounds between the 2007-2008 and 2008-2009 seasons?"
    # Use asyncio.run(...) if you are running this in a script.
    await Console(team.run_stream(task=task))

"""
Using Swarm GroupChat, Hand-off messages to agents. 
Can be an alternative to FSM based custom transitions in Autogen 0.2

This example also shows how to use Human-in-the-loop feature, 
by handing off to a user in order to get the required inputs and then proceed with the task.
"""
def refund_flight(flight_id: str) -> str:
    """Refund a flight"""
    return f"Flight {flight_id} refunded"

async def team_swarm_groupchat_with_platform_client():

    refund_flight_tool = FunctionTool(refund_flight, description="Gives the flight id to refund the flight")

    travel_agent = AssistantAgent(
        "travel_agent",
        model_client=lab45_client,
        handoffs=["flights_refunder", "user"],
        system_message="""You are a travel agent.
        The flights_refunder is in charge of refunding flights.
        If you need information from the user, you must first send your message, then you can handoff to the user.
        Use TERMINATE when the travel planning is complete.""",
    )

    flights_refunder = AssistantAgent(
        "flights_refunder",
        model_client=lab45_client,
        handoffs=["travel_agent", "user"],
        tools=[refund_flight_tool],
        system_message="""You are an agent specialized in refunding flights.
        You only need flight reference numbers to refund a flight.
        You have the ability to refund a flight using the refund_flight tool.
        If you need information from the user, you must first send your message, then you can handoff to the user.
        When the transaction is complete, handoff to the travel agent to finalize.""",
    )

    termination = HandoffTermination(target="user") | TextMentionTermination("TERMINATE")
    team = Swarm([travel_agent, flights_refunder], termination_condition=termination)

    task = "I need to refund my flight."

    task_result = await Console(team.run_stream(task=task))
    last_message = task_result.messages[-1]

    while isinstance(last_message, HandoffMessage) and last_message.target == "user":
        user_message = input("User: ")

        task_result = await Console(
            team.run_stream(task=HandoffMessage(source="user", target=last_message.source, content=user_message))
        )
        last_message = task_result.messages[-1]

if __name__ == "__main__":
    asyncio.run(team_swarm_groupchat_with_platform_client())
