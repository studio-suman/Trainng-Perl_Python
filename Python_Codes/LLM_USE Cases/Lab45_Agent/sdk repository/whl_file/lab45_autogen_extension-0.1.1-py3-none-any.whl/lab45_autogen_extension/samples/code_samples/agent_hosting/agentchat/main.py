from autogen_agentchat.messages import TextMessage
from fastapi import FastAPI, HTTPException

from run_workflow import execute_workflow

app = FastAPI()


@app.post("/execute", response_model=TextMessage)
async def chat(request: TextMessage) -> TextMessage:
    try:
        response = await execute_workflow(request)
        return response
    except Exception as e:
        error_message = {
            "type": "error",
            "content": f"Error: {str(e)}",
            "source": "system"
        }
        raise HTTPException(status_code=500, detail=error_message) from e

async def chat_simulate(query, tenant_id, session_id, user_id, api_key):
    query = TextMessage(content=query, source="user")
    response = await execute_workflow(tenant_id=tenant_id, session_id=session_id, user_id=user_id, api_key=api_key, query=query)
    print(response)
    return response

# Example usage
if __name__ == "__main__":
    # import uvicorn
    import asyncio
    query = "What is my name?"
    tenant_id = "tenant_id"
    user_id = "user_id"
    session_id = "session_id"
    api_key = "<api-key>"

    asyncio.run(chat_simulate(query, tenant_id, session_id, user_id, api_key))
    # uvicorn.run(app, host="0.0.0.0", port=8001)