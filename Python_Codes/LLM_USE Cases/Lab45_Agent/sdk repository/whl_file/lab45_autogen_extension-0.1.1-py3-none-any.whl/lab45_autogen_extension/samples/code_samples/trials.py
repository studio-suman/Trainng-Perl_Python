import os
import sys
import asyncio
import json
import time
import requests
from urllib.parse import urljoin

import arxiv

from autogen_agentchat.agents import AssistantAgent
from autogen_agentchat.conditions import TextMentionTermination
from autogen_agentchat.teams import RoundRobinGroupChat
from autogen_agentchat.messages import TextMessage
from autogen_core import CancellationToken
from autogen_core.tools import FunctionTool
from autogen_ext.tools.langchain import LangChainToolAdapter

sys.path.insert(0, os.path.abspath(os.getcwd()))
from autogen_extension.lab45aiplatform_autogen_extension import Lab45AIPlatformCompletionClient
from autogen_extension.custom_tools.ragtool import Lab45AIPlatformRAGTool
from autogen_extension.custom_tools.searchtools import Lab45AIPlatformBingSearchTool

os.environ["LAB45AIPLATFORM_URL"] = "http://localhost:8000/v1.1/"
os.environ["LAB45AIPLATFORM_API_KEY"] = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkpETmFfNGk0cjdGZ2lnTDNzSElsSTN4Vi1JVSJ9.eyJhdWQiOiJhOTE5MTY0ZC04YjdjLTQzZmItODExOS1mMTk5N2Q0NWNhNGYiLCJpc3MiOiJodHRwczovL2xvZ2luLm1pY3Jvc29mdG9ubGluZS5jb20vMjU4YWM0ZTQtMTQ2YS00MTFlLTlkYzgtNzlhOWUxMmZkNmRhL3YyLjAiLCJpYXQiOjE3NDE4NTI2NDksIm5iZiI6MTc0MTg1MjY0OSwiZXhwIjoxNzQxODU3MzUxLCJhaW8iOiJBWlFBYS84WkFBQUFCelhFNURjbzlXT0JxRlNvSnIvei9raWUzTm1sdzdQSWUrT1BpSmZmRHZrMnVDOWtTUjUwc2NpV1VoMzZQeGtUSzBDcnF4MEhIcnYxZ043bHQvbXg4SlFOT2RTcVgvY2krTXo4Z0lRZW4vUFRxcmRHWnpUTENrWVQ5RzIwQ04vTVJWSE4vMXRjaWhhZmxrREZXM0FtaElrbS9BcGFmRlplVkl4Q2FMV1ZtVGh2czZraEpRVk5oNEtlQXB0aW5hRnoiLCJhenAiOiJhOTE5MTY0ZC04YjdjLTQzZmItODExOS1mMTk5N2Q0NWNhNGYiLCJhenBhY3IiOiIwIiwiZ3JvdXBzIjpbIjk1ZjU4MTE3LTBhNjAtNDljOS1hMGU3LTBkMzUyNmY5NmRmYSJdLCJuYW1lIjoiQWRpdHlhIFByYXNhZCIsIm9pZCI6IjQzN2UyNzYyLTg4YTAtNDc4MC04YTE2LWEzNGIxZTkyODdlMSIsInByZWZlcnJlZF91c2VybmFtZSI6IkFEMzU2OTc5QHdpcHJvLmNvbSIsInJoIjoiMS5BU1VBNU1TS0pXb1VIa0dkeUhtcDRTX1cyazBXR2FsOGlfdERnUm54bVgxRnlrOGxBRWtsQUEuIiwic2NwIjoiQ29udGFjdHMuUmVhZCBHcm91cE1lbWJlci5SZWFkLkFsbCBNYWlsLlJlYWQgTWFpbC5TZW5kIFBlb3BsZS5SZWFkIFBlb3BsZS5SZWFkLkFsbCBVc2VyLlJlYWQgVXNlci5SZWFkQmFzaWMuQWxsIiwic2lkIjoiMDAyZmNhNzktZGE2Ni0yZWU2LWY0MjgtYjZlZWNmMjA5MmJjIiwic3ViIjoiRmw2SmNXS0REVEVXNVJCbWgwaXgxcUlLeHRfTEd2cFcwTk8tRFd5N3pJRSIsInRpZCI6IjI1OGFjNGU0LTE0NmEtNDExZS05ZGM4LTc5YTllMTJmZDZkYSIsInV0aSI6ImUyNTVaNjNGQ2txaEFTLWhYQjVQQUEiLCJ2ZXIiOiIyLjAifQ.X4f70Uaty5nHGNUcAGVXFNJDsEzDiJpa8N3OpGk3Ba7M8wFqjpdAKpk89vhVB9CBwgqvpaBtpcSq1W7xS-VjftMTT1xCljOAX7PA7PVps9uTceTopUyP-BKYmLeyjoIXTAS_xFix6PTg482YwnYdoaIsZIe7Hw8PvTi3RSpUDKrbflJk4KCu8JnLr60JvroVze76JyzRXP2-oCmVjVLL8n-UbKB4H8M_-gmwHlhnVbdyvlBGStHczSwnJZ6K0Z6lL9x4PR4u56gmEZpD5uIJHqvbpYtWlw6RGqxoEG2aPTHX_ESr5xK7qQK2oGG1DfzWeiwx_JqzBQNuyIKkWHYsTw"

def arxiv_search(query: str, max_results: int = 1) -> str:
    """
    An academic paper search tool to search Arxiv library for papers and return the results including abstracts.
    """
    client = arxiv.Client()
    search = arxiv.Search(query=query, max_results=max_results, sort_by=arxiv.SortCriterion.Relevance)

    results = [
        {
            'title': paper.title,
            'authors': [author.name for author in paper.authors],
            'published': paper.published.strftime("%Y-%m-%d"),
            'abstract': paper.summary,
            'pdf_url': paper.pdf_url,
        }
        for paper in client.results(search)
    ]

    return json.dumps(results)

class ReseachTeam():
    """
    Research team: A Team of agents to search for academic papers on research topics and generate a literature review based on it.
    """
    def __init__(self):
        """
        Initialize the research team with agents.
        We create 3 agents for the team:
            1. Arxiv_Search_Agent: An agent that can search use Arxiv tool to search for papers related to a given topic
            2. Data_Agent: An agent which will take in the downloaded and indexed research papers as it's knowledge base and answer queries based on it.
            3. Report_Agent: An agent that can generate a literature review report based on a search topic

        These agents will make use of 3 tools:
            1. Arxiv_Search_Tool: A tool to search Arxiv for papers related to a given topic, including abstracts
            2. RAG_Tool: A tool to interact with a pre-indexed document set using a Retrieval-Augmented Generation (RAG) pipeline
            3. Bing_Search_Tool: A tool to search the web using Bing Search API
        """
        client = Lab45AIPlatformCompletionClient(
            model_name='gpt-4o'
        )
        arxiv_search_tool = FunctionTool(arxiv_search, 
                                        description="Search Arxiv for papers related to a given topic, including abstracts")
        rag_tool = LangChainToolAdapter(Lab45AIPlatformRAGTool(dataset_id="37728abd-5862-4884-a019-a1a00a3331ff", model_name="gpt-4o", top_k=30))
        bing_search_tool = LangChainToolAdapter(Lab45AIPlatformBingSearchTool())

        self.arxiv_search_agent = AssistantAgent(
            name="Arxiv_Search_Agent",
            tools=[arxiv_search_tool],
            model_client=client,
            description="An agent that can search Arxiv for papers related to a given topic, including abstracts",
            system_message="You are a helpful AI assistant. Solve tasks using your tools. Specifically, you can take into consideration the user's request and craft a search query that is most likely to return relevant academi papers.",
        )

        self.data_agent = AssistantAgent(
            name="assistant",
            model_client=client,
            model_client_stream=False,
            tools=[rag_tool, bing_search_tool],
            system_message="You are an agent which has been given a set of documents which will be your context and knowledge base. \
                Use this to answer all queries asked.",
        )

        self.report_agent = AssistantAgent(
            name="Report_Agent",
            model_client=client,
            description="Generate a report based on a given topic",
            system_message="You are a helpful resporting assistant. Your task is to synthesize data extracted into a high quality literature review including CORRECT references. You MUST write a final report that is formatted as a literature review with CORRECT references.  Your response should end with the word 'TERMINATE'",
        )

    @staticmethod
    def _get_headers():
        """
        Get the headers required for API requests.
        """
        return {
            'Content-Type': 'application/json',
            'Authorization': f"Bearer {os.getenv('LAB45AIPLATFORM_API_KEY')}"
        }
    
    def check_index_status(self, dataset_id: str, workflow_id: str) -> dict:
        """
        Check the status of the indexing workflow for a given dataset.
        """
        response = requests.get(
            urljoin(os.getenv("LAB45AIPLATFORM_URL"), f"datasets/{dataset_id}/workflow/{workflow_id}"),
            headers=self._get_headers()
        )
        if response.status_code != 200:
            raise Exception(f"Failed to get the status of the dataset. Status code: {response.status_code}, Response: {response.text}")
        return response.json()
    
    def _index_files(self, files: list = [], dataset_id: str = None):
        """
        Index files into the dataset.
        """
        # Ingest files
        ingest_url = urljoin(os.getenv("LAB45AIPLATFORM_URL"), f"datasets/{dataset_id}/ingest")
        headers = self._get_headers()
        headers.pop('Content-Type')
        ingest_response = requests.request("POST", ingest_url, headers=headers, data={}, files=files)
        if ingest_response.status_code != 200:
            raise Exception(f"Failed to upload files to the dataset. Status code: {ingest_response.status_code}, Response: {ingest_response.text}")
        
        # Prepare indexing
        payload = json.dumps({"dataset_id": dataset_id})
        prepare_response = requests.post(
            urljoin(os.getenv("LAB45AIPLATFORM_URL"), "skills/doc_completion/prepare"),
            headers=self._get_headers(),
            data=payload
        )
        if prepare_response.status_code != 200:
            raise Exception(f"Failed to prepare the dataset. Status code: {prepare_response.status_code}, Response: {prepare_response.text}")
        
        response_data = prepare_response.json()
        status = response_data["status"]
        workflow_id = response_data["_id"]

        # Poll for indexing status
        retry = 0
        while status in ['Started', 'Waiting', 'Indexing']:
            if retry > 5:
                raise Exception(f"Failed to index the dataset. Status: {status}")
            time.sleep(10)
            retry += 1
            status_response = self.check_index_status(dataset_id, workflow_id)
            status = status_response["status"]
        
        return True

    async def search_and_report_with_platform_client(self):
        """
        A basic search team which, based on the query provided, uses already indexed documents or 
        searches the web to generate a literature report on the said topic.

        Here the data_agent has both RAG and Bing search tools to available to it. 
        It can leverage either of them to answer queries based on query.
        """
        termination = TextMentionTermination("TERMINATE")
        team = RoundRobinGroupChat(
            participants=[self.data_agent, self.report_agent], termination_condition=termination
        )
        response = await team.run(task="What is Llama adapter?")
        print(response)

    async def arxiv_search_index_and_report_with_platform_client(self, search_topic: str):
        """
        An advanced research team which searches for academic papers on a given topic, 
        downloads the papers, indexes them, and generates a literature review based on the indexed papers.
        """
        response = await self.arxiv_search_agent.on_messages(
            [TextMessage(content=f"Find relevant academic papers on the topic: {search_topic}", source="user")],
            cancellation_token=CancellationToken(),
        )
        
        print(response.chat_message)
        results = json.loads(response.chat_message.content)
        if not results:
            raise ValueError("No results found")
        
        # Create a local folder 'academic_files' if it doesn't exist
        local_folder = 'academic_files'
        os.makedirs(local_folder, exist_ok=True)

        # Download files into the local folder and prepare the list for indexing
        files = []
        for content in results:
            file_name = f"{content['title'][:10]}.pdf"
            file_path = os.path.join(local_folder, file_name)
            with open(file_path, 'wb') as file:
                file.write(requests.get(content['pdf_url']).content)
                files.append((file_name, (file_name, open(file_path, 'rb'), 'application/pdf')))

        # index the papers
        index_status = self._index_files(files=files, dataset_id="e4142591-9297-4b79-9c71-4e5aedabefd0")

        if index_status:
            termination = TextMentionTermination("TERMINATE")
            team = RoundRobinGroupChat(
                participants=[self.data_agent, self.report_agent], termination_condition=termination
            )
            response = await team.run(task=f"Write a literature review on {search_topic} for ai systems using the indexed papers")
            print(response)

if __name__ == "__main__":
    asyncio.run(ReseachTeam().arxiv_search_index_and_report_with_platform_client(search_topic="Llama adapter"))