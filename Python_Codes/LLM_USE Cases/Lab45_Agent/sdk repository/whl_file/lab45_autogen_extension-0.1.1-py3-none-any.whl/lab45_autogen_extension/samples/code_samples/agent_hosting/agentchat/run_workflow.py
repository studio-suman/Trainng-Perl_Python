import os
import sys
import aiofiles
import json
from typing_extensions import Unpack
from autogen_agentchat.agents import AssistantAgent
from lab45_autogen_extension.lab45aiplatform_autogen_extension import Lab45AIPlatformCompletionClient
from lab45_autogen_extension.utils import Lab45AIPlatformStateStoreConfiguration
from autogen_core import CancellationToken


async def get_agent(lab45_client) -> AssistantAgent:
    """Get the assistant agent, load state from file."""

    # Create the assistant agent.
    agent = AssistantAgent(
        name="assistant",
        model_client=lab45_client,
        system_message="You are a helpful assistant.",
    )

    return agent

# Do not change the method and module name
async def execute_workflow(**kwargs: Unpack[Lab45AIPlatformStateStoreConfiguration]):
    query = kwargs.get("query")
    tenant_id = kwargs.get("tenant_id")
    user_id = kwargs.get("user_id")
    session_id = kwargs.get("session_id")
    api_key = kwargs.get("api_key")

    # initialize extension client
    lab45_client = Lab45AIPlatformCompletionClient(
        model_name='gpt-4o',
        base_url="http://localhost:8000/v1.1/",
        api_key=api_key, 
        enable_state_storage=True  # enable this in order to save and load states to the extension sqlite DB
    )
    
    # replace with agent logic, return agent object
    agent = await get_agent(lab45_client)

    # Save agent state from sqlite 
    state = lab45_client.load_state(tenant_id=tenant_id, session_id=session_id, user_id=user_id)
    if state: 
        await agent.load_state(state)

    # generate response from agent
    response = await agent.on_messages(messages=[query], cancellation_token=CancellationToken())

    # Save agent state to sqlite 
    state = await agent.save_state()
    lab45_client.save_state(tenant_id=tenant_id, session_id=session_id, user_id=user_id, state=state)

    return response.chat_message

