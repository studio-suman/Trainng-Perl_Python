# Stock Price Prediction Assistant involving intensive calculations using Lab45 AI Platform's Autogen extension library

## Overview
This script demonstrates the usage of the `lab45_autogen_extension` library to create a computationally intensive assistant that predicts stock prices using a variety of methods. The assistant uses custom tools to perform simulations and regression-based predictions. It also fetches time series data from an external API (BSE) to predict stock prices for the next day.

### Key Features
1. **Monte Carlo Simulation**: Predicts the stock price based on random simulations of price changes over time.
2. **Linear Regression**: Predicts the next day's stock price based on historical data using a linear regression model.
3. **External API Integration**: Fetches stock data from the BSE (Bombay Stock Exchange) using the Alpha Vantage API and calculates the next day's price based on historical data.

The assistant can handle multiple tasks and respond to user queries regarding stock prices by utilizing these advanced computation techniques.

## Dependencies
This script requires the following Python libraries:
- `autogen-agentchat==0.4.5`
- `autogen-core==0.4.5`
- `autogen-ext==0.4.5`
- `numpy`
- `pandas`
- `requests`
- `sklearn`

You can install the necessary libraries using pip:

```bash
pip install numpy pandas requests scikit-learn
```

## Configuration Items
1. **LAB45AIPLATFORM_URL**: https://devapi.lab45.ai/v1.1/ or https://stagingapi.lab45.ai/v1.1/
2. **LAB45AIPLATFORM_API_KEY**: Your JWT TOKEN
3. **ALPHA_VANTAGE_API_KEY**: Generate a free API KEY from https://www.alphavantage.co/

## Source Code
```python
import asyncio
import random
import requests
import json
import os
from sklearn.linear_model import LinearRegression
from datetime import datetime
import numpy as np
import pandas as pd
from autogen_core.tools import FunctionTool
from autogen_agentchat.agents import AssistantAgent
from autogen_agentchat.messages import TextMessage
from autogen_core import CancellationToken
from lab45_autogen_extension.lab45aiplatform_autogen_extension import Lab45AIPlatformCompletionClient

os.environ["LAB45AIPLATFORM_URL"] = "https://devapi.lab45.ai/v1.1/"
os.environ["LAB45AIPLATFORM_API_KEY"] = "YOUR JWT TOKEN"


async def get_stock_price(ticker: str, date: str) -> float:
    """
    Simulate a Monte Carlo simulation to predict stock price based on historical data.
    This is computationally expensive.
    """
    print(f"Getting stock price for {ticker} on {date}")  # Log when the function is called
    np.random.seed(42)
    num_simulations = 1000  # Number of simulations to run
    num_days = 252  # Number of days in a year (for financial models)

    # Simulated data (this could be more realistic if fetching historical data)
    initial_price = random.uniform(100, 500)
    volatility = random.uniform(0.1, 0.3)  # Simulated volatility (10% - 30%)
    drift = random.uniform(0.01, 0.05)  # Simulated drift (1% - 5%)

    simulations = []
    for _ in range(num_simulations):
        daily_returns = np.random.normal(loc=drift / num_days, scale=volatility / np.sqrt(num_days), size=num_days)
        price_series = initial_price * np.exp(np.cumsum(daily_returns))  # Simulated price series
        simulations.append(price_series[-1])  # Collect final price

    # Return average of all simulated prices
    predicted_price = np.mean(simulations)
    print(f"Predicted price: {predicted_price:.2f}")  # Log the predicted price
    return predicted_price

async def get_stock_details(stock_name: str) -> str:
    """
    Simulate complex data analysis (e.g., Linear Regression on stock data)
    This is computationally expensive.
    """
    # Simulate loading historical stock data for the given stock name
    # For simplicity, generate some random stock price data
    np.random.seed(42)
    num_days = 252  # Number of trading days in a year
    historical_prices = np.random.normal(loc=100, scale=20, size=num_days)  # Randomized stock prices

    # Create a DataFrame for the stock prices
    dates = pd.date_range(start='2020-01-01', periods=num_days, freq='B')  # Business days
    df = pd.DataFrame({'Date': dates, 'Price': historical_prices})

    # Perform Linear Regression to predict next day's price based on historical prices
    df['Day'] = np.arange(len(df))  # Create a "Day" feature for the model (0, 1, 2, ...)
    
    # Linear Regression Model
    model = LinearRegression()
    model.fit(df['Day'].values.reshape(-1, 1), df['Price'].values)
    
    # Predict the next day's price (out of sample prediction)
    next_day = np.array([[len(df)]])  # Next day (Day = 253)
    predicted_price = model.predict(next_day)[0]
    print(f"next_day = {next_day} | predicted_price = {model.predict(next_day)[0]}")

    return f"Predicted price for {stock_name} on the next day: {predicted_price:.2f} USD"

async def predict_next_day_price_with_historical_daily_data_from_bse(stock_name: str) -> str:
    """
    Calculate Time series daily for a given stock_name.
    """
    ## free api key can be generated from https://www.alphavantage.co/
    ALPHA_VANTAGE_API_KEY = "YOUR DEV KEY"
    URL = f"https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol={stock_name}.BSE&outputsize=full&apikey={ALPHA_VANTAGE_API_KEY}"
    response = requests.get(url=URL)
    data = response.json()
    metadata = data.get('Meta Data')
    print(f"metadata => {metadata}")
    time_series_daily = data.get('Time Series (Daily)')
    print(f"time_series_daily type => {type(time_series_daily)}")
    # sort the dates 
    date_list = list(time_series_daily.keys())
    # Convert the date strings to datetime objects and sort the list
    sorted_dates = sorted(date_list, key=lambda x: datetime.strptime(x, '%Y-%m-%d'), reverse=True)
    # store it into json to store the complete data
    with open(f"{stock_name}_time_series_data.json", "w") as f:
        json.dump(time_series_daily, f, indent=4)

    # now to calculate the stock price for next day take the last x days values
    last_100_days_closes = [float(time_series_daily[date]['4. close']) for date in sorted_dates[:100]]

    # Calculate the simple moving average (SMA) of the last 100 days' closing prices
    sma = np.mean(last_100_days_closes)
    
    # Predict the next day's price by using the SMA (this is a simple prediction model)
    predicted_price = sma
    
    print(f"Predicted price for next day: {predicted_price:.2f}")
    
    return f"Predicted price for next day: {predicted_price:.2f}"

async def assistant_chat_with_custom_tool_compute_intesive_simulation():
    """
    Non-streaming
    Create an assistant agent with a custom tool/function
    """
    client = Lab45AIPlatformCompletionClient(
        model_name='gpt-4o'
    )

    # Create function calls for complex computations
    tool_1 = FunctionTool(get_stock_price, description="Perform Monte Carlo simulation to predict stock price")
    tool_2 = FunctionTool(get_stock_details, description="Perform linear regression to predict next day's stock price")

    agent = AssistantAgent(
        name="assistant",
        model_client=client,
        model_client_stream=False,
        tools=[tool_1, tool_2],  # Ensure both tools are included here
        system_message="You are an assistant that can predict stock prices based on computational models. "
                       "Use the Monte Carlo simulation to predict stock prices and use linear regression for future price prediction.",
    )

    print("Waiting for response from agent...")  # Log that we're waiting for the response

    # Non-Streaming: Wait for a response to a query about stock price prediction
    response = await agent.on_messages(
        [TextMessage(content="What is the predicted stock price of AAPL on the next day?", source="user")],
        cancellation_token=CancellationToken(),
    )

    print(f"Response from agent: {response.chat_message}")  # Log the response
    print(response.chat_message)  # Output the agent's response

async def assistant_chat_with_custom_tool_with_api():
    """
    Non-streaming
    Create an assistant agent with a custom tool/function
    """
    client = Lab45AIPlatformCompletionClient(
        model_name='gpt-4o'
    )

    # Create function calls for calculation time series daily
    tool_1 = FunctionTool(predict_next_day_price_with_historical_daily_data_from_bse, description="predict next day price from BSE for given stock_name")

    agent = AssistantAgent(
        name="assistant",
        model_client=client,
        model_client_stream=False,
        tools=[tool_1],  # Ensure both tools are included here
        system_message="You are an assistant that can predict stock prices"
                       "get the time series daily for stock_name WIPRO from BSE and predict price for next day",
    )

    print("Waiting for response from agent...")  # Log that we're waiting for the response

    # Non-Streaming: Wait for a response to a query about stock price prediction
    response = await agent.on_messages(
        [TextMessage(content="Predict the next day price for WIPRO from BSE ", source="user")],
        cancellation_token=CancellationToken(),
    )
    
    print(f"Response from agent: {response.chat_message}")  # Log the response
    print(response.chat_message)  # Output the agent's response

if __name__ == "__main__":
    asyncio.run(assistant_chat_with_custom_tool_compute_intesive_simulation())
    asyncio.run(assistant_chat_with_custom_tool_with_api())
```
## How to Run the script
At Project root folder run the below command with separate virtual environment having dependencies installed.
```bash
python samples/assistant_chat_sample.py
```

## Sample Output
```bash
(3.11.7/envs/venv_3_11_7)  anupam@PLXYJK2FJ7  ~/autogen/Platform   autogen_intensive_calculation  python samples/assistant_chat_sample.py
/Users/anupam/.pyenv/versions/3.11.7/envs/venv_3_11_7/lib/python3.11/site-packages/langchain_experimental/tools/__init__.py:1: LangChainDeprecationWarning: As of langchain-core 0.3.0, LangChain uses pydantic v2 internally. The langchain.pydantic_v1 module was a compatibility shim for pydantic v1, and should no longer be used. Please update the code to import from Pydantic directly.

For example, replace imports like: `from langchain.pydantic_v1 import BaseModel`
with: `from pydantic import BaseModel`
or the v1 compatibility namespace if you are working in a code base that has not been fully upgraded to pydantic 2 yet. 	from pydantic.v1 import BaseModel

  from langchain_experimental.tools.python.tool import PythonAstREPLTool, PythonREPLTool
/Users/anupam/.pyenv/versions/3.11.7/envs/venv_3_11_7/lib/python3.11/site-packages/pydantic/_internal/_generate_schema.py:775: UserWarning: Mixing V1 models and V2 models (or constructs, like `TypeAdapter`) is not supported. Please upgrade `PythonREPL` to V2.
  warn(
Waiting for response from agent...
next_day = [[252]] | predicted_price = 102.84720730474486
Response from agent: source='assistant' models_usage=None content='Predicted price for AAPL on the next day: 102.85 USD' type='ToolCallSummaryMessage'
source='assistant' models_usage=None content='Predicted price for AAPL on the next day: 102.85 USD' type='ToolCallSummaryMessage'
Waiting for response from agent...
metadata => {'1. Information': 'Daily Prices (open, high, low, close) and Volumes', '2. Symbol': 'WIPRO.BSE', '3. Last Refreshed': '2025-03-12', '4. Output Size': 'Full size', '5. Time Zone': 'US/Eastern'}
time_series_daily type => <class 'dict'>
Predicted price for next day: 10371.82
Response from agent: source='assistant' models_usage=None content='Predicted price for next day: 10371.82' type='ToolCallSummaryMessage'
source='assistant' models_usage=None content='Predicted price for next day: 10371.82' type='ToolCallSummaryMessage'
(3.11.7/envs/venv_3_11_7)  anupam@PLXYJK2FJ7  ~/autogen/Platform   autogen_intensive_calculation ± 
```