import asyncio
import os
import random
import sys
import pandas as pd
from typing_extensions import Annotated
from autogen_core import CancellationToken
from autogen_core.tools import FunctionTool
from autogen_agentchat.agents import AssistantAgent
from autogen_agentchat.messages import TextMessage
from autogen_ext.tools.langchain import LangChainToolAdapter
from langchain_experimental.tools.python.tool import PythonAstREPLTool

# sys.path.insert(0, os.path.abspath(os.getcwd()))
from lab45_autogen_extension.custom_tools.ragtool import Lab45AIPlatformRAGTool
from lab45_autogen_extension.lab45aiplatform_autogen_extension import Lab45AIPlatformCompletionClient

os.environ["LAB45AIPLATFORM_URL"] = "http://localhost:8000/v1.1/"
os.environ["LAB45AIPLATFORM_API_KEY"] = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkpETmFfNGk0cjdGZ2lnTDNzSElsSTN4Vi1JVSJ9.eyJhdWQiOiJhOTE5MTY0ZC04YjdjLTQzZmItODExOS1mMTk5N2Q0NWNhNGYiLCJpc3MiOiJodHRwczovL2xvZ2luLm1pY3Jvc29mdG9ubGluZS5jb20vMjU4YWM0ZTQtMTQ2YS00MTFlLTlkYzgtNzlhOWUxMmZkNmRhL3YyLjAiLCJpYXQiOjE3NDI4Njg0ODAsIm5iZiI6MTc0Mjg2ODQ4MCwiZXhwIjoxNzQyODcyOTU2LCJhaW8iOiJBYVFBVy84WkFBQUFvT01SS1BLWFJIQytTOHIrRWlCUUttNVd0N2JUbk5WWS9OOWhwODJkdVJPSXkrNzRwdE5VUWhMZzE4T1Rua3g3Q1dBNkFNdVhNY2RiVXd5WW1Wd3hKUVluV0VYcnNWajBodjlnSzh1OHNCOXhmM21oNVRGcjI2c0lNOTcwYnFBb1lBajZ3TlhpbEJiVHJ6SjdvMnRyaFJKenRvNVY5UU9lZGJHMHNLTisyNTBIQXV5THlOTjFsTG9OVlVnTmJoelltUWduTCsxQ0VIUGdIbWJNeXZGL1RBPT0iLCJhenAiOiJhOTE5MTY0ZC04YjdjLTQzZmItODExOS1mMTk5N2Q0NWNhNGYiLCJhenBhY3IiOiIwIiwiZ3JvdXBzIjpbIjk1ZjU4MTE3LTBhNjAtNDljOS1hMGU3LTBkMzUyNmY5NmRmYSJdLCJuYW1lIjoiQWRpdHlhIFByYXNhZCIsIm9pZCI6IjQzN2UyNzYyLTg4YTAtNDc4MC04YTE2LWEzNGIxZTkyODdlMSIsInByZWZlcnJlZF91c2VybmFtZSI6IkFEMzU2OTc5QHdpcHJvLmNvbSIsInJoIjoiMS5BU1VBNU1TS0pXb1VIa0dkeUhtcDRTX1cyazBXR2FsOGlfdERnUm54bVgxRnlrOGxBRWtsQUEuIiwic2NwIjoiQ29udGFjdHMuUmVhZCBHcm91cE1lbWJlci5SZWFkLkFsbCBNYWlsLlJlYWQgTWFpbC5TZW5kIFBlb3BsZS5SZWFkIFBlb3BsZS5SZWFkLkFsbCBVc2VyLlJlYWQgVXNlci5SZWFkQmFzaWMuQWxsIiwic2lkIjoiMDAzMTc4MjktNjI4YS0xMTAzLTAyNGYtMDYzMTYwNWJjNzVmIiwic3ViIjoiRmw2SmNXS0REVEVXNVJCbWgwaXgxcUlLeHRfTEd2cFcwTk8tRFd5N3pJRSIsInRpZCI6IjI1OGFjNGU0LTE0NmEtNDExZS05ZGM4LTc5YTllMTJmZDZkYSIsInV0aSI6Ilh5bE9QOXRrYkVTb3Z5Z1RuTFU1QUEiLCJ2ZXIiOiIyLjAifQ.giu5bmhfrtMiYrGsGTF9gHIySGmsJd4QEfymQqK7nM-jo0pWDstWTKFkEP3x_VVkG0ksCIh3T_chtJLglPlUQK9lEN-OizPv3GjFpCGrfPmlo4yGs-Ur38AbSFzZO1AUWJTuAg8okgG5MC2rNQ4AlnYML--zZ75w0gbGmVk100Rs8gEroXC62kq8h0Z5IChrcGjhVr05HdDbI7YTJ5OhAy2g_2U4tar-w6oQqDg45kMCnmrr3oN6WgfWGPKjKIemkIJXcffckolTFHqy95RjIvSytjUTCM38C7v5I0RPgVMl8EXyqeCnhekXJmqbURd3wp8qfUs-9SlMMTfSlnchGA"

# Create a Lab45 AI Platform completion client
lab45_client = Lab45AIPlatformCompletionClient(
        model_name='gpt-4o'
    )

# custom tool 1
async def get_stock_price(ticker: str, date: Annotated[str, "Date in YYYY/MM/DD"]) -> float:
    # Simulates a stock price retrieval by returning a random float within a specified range.
    return random.uniform(10, 200)

# custom tool 2
async def get_stock_details(stock_name: str):
    # Simulates sending back the details of the selected stock based on the stock's name as input
    return "{'name': 'Sample_stock'}"

async def assistant_chat_with_custom_tool():
    """
    Non-streaming
    Create an assistant agent with a custom tool/function
    """
    # create function call
    tool_1 = FunctionTool(get_stock_price, description="Fetch the stock price for a given ticker from the given context")
    tool_2 = FunctionTool(get_stock_details, description="Fetch the name of the stock for a given ticker from the given context")

    agent = AssistantAgent(
        name="assistant",
        model_client=lab45_client,
        model_client_stream=False,
        tools=[tool_1, tool_2],
        system_message="Your name is AutogenAssist, you are a general purpose AI assistant which can help with user queries, /"
                       "When asked to fetch the stock price of given ticker, give ticker value as 'AAPL' and date as '2021/01/01'."
    )

    # Non-Streaming
    response = await agent.on_messages(
        [TextMessage(content="what is the stock price of AAPL on date 2021/01/01? Also, give the name of the stock", source="user")],
        cancellation_token=CancellationToken(),
    )
    print(response.chat_message)


async def assistant_chat_with_langchain_tool():
    """
    Assistant agent with an existing LangChain tool
    """

    df = pd.read_csv(
        "https://raw.githubusercontent.com/pandas-dev/pandas/main/doc/data/titanic.csv")
    tool = LangChainToolAdapter(PythonAstREPLTool(locals={"df": df}))

    agent = AssistantAgent(
        name="assistant",
        model_client=lab45_client,
        model_client_stream=False,
        tools=[tool],
        system_message="Use the `df` variable to access the dataset.",
    )

    # Non-Streaming
    response = await agent.on_messages(
        [TextMessage(content="What's the average age of the passengers?", source="user")],
        cancellation_token=CancellationToken(),
    )
    print(response.chat_message)


async def assistant_chat_with_platform_tool():
    """
    Assistant agent with an in-house Lab45 AI Platform tool [Lab45AIPlatformText2ImageTool] using DallE,
    for text to image generation.
    """

    from lab45_autogen_extension.custom_tools.imagetools import Lab45AIPlatformText2ImageTool
    from autogen_ext.tools.langchain import LangChainToolAdapter
    image_tool = LangChainToolAdapter(Lab45AIPlatformText2ImageTool('dalle'))

    agent = AssistantAgent(
        name="assistant",
        model_client=lab45_client,
        model_client_stream=False,
        tools=[image_tool],
        system_message="You are an agent which can generate images from text using tools attached. \
            You can take in text query and generate images if the the query asks for it.",
    )

    response = await agent.on_messages(
        [TextMessage(content="Generate an image of a football", source="user")],
        cancellation_token=CancellationToken(),
    )
    print(response.chat_message)


async def assistant_chat_with_platform_rag_tool():
    """
    Assistant agent with a Lab45 AI Platform RAG/Doc completion tool.
    Requires a pre-existing dataset id. 
    Platform APIs can be used to create a dataset, ingest documents and index extracted text.
    """
    rag_tool = LangChainToolAdapter(Lab45AIPlatformRAGTool(dataset_id="37728abd-5862-4884-a019-a1a00a3331ff", model_name="gpt-4o", top_k=15))

    agent = AssistantAgent(
        name="assistant",
        model_client=lab45_client,
        model_client_stream=False,
        tools=[rag_tool],
        system_message="You are an agent which has been given a set of documents which will be your context and knowledge base. \
            Use this to answer all queries asked.",
    )

    response = await agent.on_messages(
        [TextMessage(content="ctx: ..., query: What is a llama adapter?", source="user")],
        cancellation_token=CancellationToken(),
    )
    print(response.chat_message)


if __name__ == "__main__":
    asyncio.run(assistant_chat_with_custom_tool())