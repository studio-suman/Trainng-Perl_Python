# CSV Data Analysis with LAB45AI autogen extended library and LangChain

This document explains how to use the `lab45_autogen_extension` library with LangChain tools to analyze CSV data through natural language queries.

## Overview

The `assistant_with_csv.py` script demonstrates how to create an AI assistant that can:

1. Load and analyze CSV data files
2. Respond to natural language queries about the data
3. Execute Python code through LangChain's REPL tool
4. Generate insightful responses using the LAB45AI Platform

This integration enables users to interact with data through conversation rather than writing code directly.

## How It Works

The script combines several powerful components:

* **LAB45AI Platform**: Provides the language model capabilities
* **LangChain Tools**: Offers Python code execution abilities
* **Pandas**: Handles the data manipulation and analysis
* **AutoGen**: Manages the agent conversation flow

### The Process Flow

1. Load a CSV file into a pandas DataFrame
2. Create a Python REPL tool that has access to this DataFrame
3. Connect this tool to a LAB45AI assistant agent
4. Send queries to the agent about the data
5. The agent uses the tool to analyze the data and responds with insights

## Dependencies
This script requires the following Python libraries:
- `autogen-agentchat==0.4.5`
- `autogen-core==0.4.5`
- `autogen-ext==0.4.5`
- `langchain_experimental`

You can install the necessary libraries using pip mentioned above:
sample:
```bash
pip install langchain_experimental
```
## Key Components

### LAB45AI Platform Client

```python
client = Lab45AIPlatformCompletionClient(
    model_name='gpt-4o'
)
```
The client connects to the LAB45AI Platform API using the provided API key and model configuration.


## CSV Data Loading

```python
    df = pd.read_csv(
    "https://raw.githubusercontent.com/pandas-dev/pandas/main/doc/data/titanic.csv")
```

The script loads the famous Titanic dataset, but you can replace this with any CSV file.

## LangChain Python Tool

```python 
    tool = LangChainToolAdapter(PythonAstREPLTool(locals={"df": df}))
```

**Tool Description**:

This tool allows the agent to:

Execute Python code
Access the DataFrame through the variable df
Run pandas operations and analyses
Return results to be incorporated in responses.

## Assistant Agent Configuration

```python
agent = AssistantAgent(
    name="assistant",
    llm_client=client,
    system_message="""You are a data analysis assistant.
    You have access to a Python tool that can execute code.
    The data is available in a pandas DataFrame named 'df'.
    When you need to analyze data, write Python code and use the tool to execute it.
    After execution, explain the results in plain language.
    """,
    tools=[tool]
)
```

## To run:

## Running the CSV Analysis Assistant

The script is designed to be run directly, with a simple entry point that leverages Python's asynchronous capabilities:

```python
if __name__ == "__main__":
    asyncio.run(assistant_chat_with_langchain_csv_tool())

```

## Example Usage and Responses

When interacting with the CSV data analysis assistant, you'll observe how it processes queries and returns responses with tool call results.

### Query Processing Flow

1. **User Query**: You ask a question about the data
2. **Tool Execution**: The assistant invokes the Python REPL tool to analyze the data
3. **Results Processing**: The assistant interprets the code execution results
4. **Response Generation**: A human-friendly explanation is provided

response: source='assistant' models_usage=None content='29.69911764705882' type='ToolCallSummaryMessage'

### Response Format

The response includes metadata about the tool usage and results:

This tells us:
- `source='assistant'`: The message came from the assistant agent
- `models_usage=None`: Model usage tracking information (if available)
- `content='29.69911764705882'`: The actual result from the code execution
- `type='ToolCallSummaryMessage'`: This is a summary of a tool call result

### Example Interaction

**User Query:**
"What is the average age of passengers on the Titanic?"

**Assistant's Process:**
1. The assistant recognizes this requires calculating the mean of the 'Age' column
2. It executes Python code using the tool:
   ```python
   df['Age'].mean()

## Full code

```python

import asyncio
import os
import pandas as pd
from langchain_experimental.tools.python.tool import PythonAstREPLTool
from autogen_ext.tools.langchain import LangChainToolAdapter
from autogen_agentchat.agents import AssistantAgent
from autogen_agentchat.messages import TextMessage
from autogen_core import CancellationToken

# Ensure the import paths are correct
import sys
sys.path.insert(0, os.path.abspath(os.getcwd()))
from lab45_autogen_extension.lab45aiplatform_autogen_extension import Lab45AIPlatformCompletionClient

#os.environ["LAB45AIPLATFORM_URL"] = "http://localhost:8000/v1.1/"
os.environ["LAB45AIPLATFORM_URL"] = "https://devapi.lab45.ai/v1.1/"
os.environ["LAB45AIPLATFORM_API_KEY"] = "User Jwt token or developer key"

"""
please install the following packages:
pip install langchain_experimental
"""

async def assistant_chat_with_langchain_csv_tool():
    """
    Assistant agent with a LangChain tool
    """
    client = Lab45AIPlatformCompletionClient(
        model_name='gpt-4o'
    )

    df = pd.read_csv(
        "https://raw.githubusercontent.com/pandas-dev/pandas/main/doc/data/titanic.csv")
    tool = LangChainToolAdapter(PythonAstREPLTool(locals={"df": df}))

    agent = AssistantAgent(
        name="assistant",
        model_client=client,
        model_client_stream=False,
        tools=[tool],
        system_message="Use the `df` variable to access the dataset.",
    )

    # Non-Streaming
    response = await agent.on_messages(
        [TextMessage(content="What's the average age of the passengers?", source="user")],
        cancellation_token=CancellationToken(),
    )
    print(response.chat_message)
    print("Response:", response.chat_message.content)

if __name__ == "__main__":
    asyncio.run(assistant_chat_with_langchain_csv_tool())

```

## Benefits:

    No-Code Data Analysis: Users can get insights without writing Python code
    Natural Language Interface: Ask questions in plain English
    Powerful Analysis: Access to the full capabilities of pandas and Python
    Contextual Understanding: The agent understands follow-up questions
    Explanatory Responses: Results are explained in easy-to-understand language
    Advanced Capabilities

## This system can handle complex analytical tasks including:

    Statistical analysis and hypothesis testing
    Data visualization recommendations
    Identifying trends and patterns
    Data cleaning suggestions
    Feature engineering for machine learning
