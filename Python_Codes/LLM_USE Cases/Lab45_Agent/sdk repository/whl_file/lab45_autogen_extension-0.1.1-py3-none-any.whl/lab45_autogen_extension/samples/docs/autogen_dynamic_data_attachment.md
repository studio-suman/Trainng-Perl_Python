# Dynamic Data Attachment Using Lab45 AI Platform Extended Autogen Library

This document provides a comprehensive guide on utilizing the `lab45_autogen_extension` library to augment the contextual data used by a Retrieval-Augmented Generation (RAG) agent by dynamically attaching extra document data alongside the pre-existing, vectored data within a Lab45 AI platform dataset. This technique enables you to query and receive precise, combined responses that leverage information from both the dataset and an external PDF document.

## Creating client with Lab45 AI extention:

This client handles interactions with the specified model on the Lab45 AI platform.

```python
from lab45_autogen_extension.lab45aiplatform_autogen_extension import Lab45AIPlatformCompletionClient
client = Lab45AIPlatformCompletionClient(
    model_name='gpt-4o'
)
```

## Extract Text from PDF Document:

This section reads a PDF file and extracts its textual content.

```python
pdf_file_path = "path/to/your/document.pdf"
pdf_text = ""
with open(pdf_file_path, 'rb'):
    reader = PdfReader(pdf_file_path)
    for page in reader.pages:
        pdf_text += page.extract_text() or ""
```

## Initialize RAG Tool with Dataset and Message History

This creates a Retrieval-Augmented Generation (RAG) tool that uses a dataset and message history for context.

```python
from lab45_autogen_extension.custom_tools.ragtool import Lab45AIPlatformRAGTool
from autogen_ext.tools.langchain import LangChainToolAdapter
dataset_id = "fc487d2d-8b81-4cb7-9243-1e0bb6694df1"  # Replace with your actual dataset ID
rag_tool = LangChainToolAdapter(Lab45AIPlatformRAGTool(dataset_id=dataset_id, model_name="gpt-4o", top_k=100, message_history=[{'content': pdf_text, 'name': 'user', 'role': 'user'}]))
```

## Create Agent using Platform's Model Client and RAG Tool:

This agent will use the RAG tool and the Lab45 AI platform client to answer queries.

```python
agent = AssistantAgent(
    name="assistant",
    model_client=client,
    model_client_stream=False,
    tools=[rag_tool],
    system_message="You are an agent which has been given a set of documents which will be your context and knowledge base. Use this to answer all queries asked.",
)
```

## Quering on the context present in Dataset and PDF file:

This sends a query to the agent, which will use the RAG tool to retrieve relevant information from the data present in dataset and message history

```python
query_with_context = f"Question: Based on the context provided, tell me about 'The Impact of Football on Society' and 'The FIFA World Cup'"
response = await agent.on_messages(
    [TextMessage(content=query_with_context, source="user")],
    cancellation_token=CancellationToken(),
)
```