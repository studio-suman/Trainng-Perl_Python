class Lab45AIPlatformRequestError(Exception):
    """
    Error raised when an exception occurs while sending and parsing a request from the platform's completion API
    """
    def __init__(self, message, errors=None) -> None:
        self.message = f"Platform completion API failed with error msg: {message}"
        self.errors= errors
        super().__init__(self.message)

class Lab45AIPlatformToolRequestError(Exception):
    """
    Error raised when an exception occurs while sending and parsing a tool call related
    request from the platform's completion API
    """
    def __init__(self, message, errors=None) -> None:
        self.message = f"Tool call execution API failed with error msg: {message}"
        self.errors= errors
        super().__init__(self.message)

class Lab45AIPlatformSQLStateStorageError(Exception):
    """
    Error raised when an exception occurs while saving or loading a state from SQLLite DB
    """
    def __init__(self, message, errors=None) -> None:
        self.message = f"Exception in state storage: {message}"
        self.errors= errors
        super().__init__(self.message)