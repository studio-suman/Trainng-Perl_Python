# The PR contains
* [ ] Code
* [ ] Test cases
* [ ] Documentation
* [ ] Something else

# What does your Code
1.
2.
3.

# Did you read the [CONTRIBUTING.md](https://github.com/SimonWaldherr/golibs/blob/master/CONTRIBUTING.md)


# On which system have you tested
* Architecture: 
* OS: 
* Go: 
* ... 
