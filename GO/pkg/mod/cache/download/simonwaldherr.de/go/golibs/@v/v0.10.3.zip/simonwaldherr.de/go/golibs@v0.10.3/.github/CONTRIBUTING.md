Thank you for considering to contribute!

a Pull Request must comply to the following rules:

* ```go fmt``` your code
* make test cases (coverage above 50%)
* ```go test``` must successfully finish
* provide your code under a matching license
  * you agree that your code will be published with the rest of this repo

