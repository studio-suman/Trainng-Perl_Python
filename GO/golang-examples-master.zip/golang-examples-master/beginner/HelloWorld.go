package main

func main() {
	// print string
	print("Hello World\n")
}
