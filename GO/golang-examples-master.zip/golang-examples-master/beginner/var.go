package main

// import required modules
import (
	"fmt"
)

// declare variables
var variable string

func main() {

	// define content of variable
	variable = "Lorem Ipsum Dolor Sit Amet"

	// print variable
	fmt.Println(variable)
}
