//usr/bin/env go run $0 $@ ; exit

package main

func main() {
	// print string
	print("Hello World\n")
}
