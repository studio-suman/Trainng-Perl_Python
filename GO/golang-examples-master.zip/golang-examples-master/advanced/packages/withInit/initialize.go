package initialize

import (
	"fmt"
)

func init() {
	fmt.Println("init package \"initialize\"")
}
