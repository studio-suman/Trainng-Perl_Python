package codegen

type Data struct {
	Amet   float64 `json:"amet"`
	Bar    bool    `json:"bar"`
	Dolor  string  `json:"dolor"`
	FooBar bool    `json:"foo_bar"`
	Lorem  string  `json:"lorem"`
}
