package main

import (
	assembly "./assembly"
	"fmt"
)

func main() {
	fmt.Println(assembly.Add(32, 64))
}
